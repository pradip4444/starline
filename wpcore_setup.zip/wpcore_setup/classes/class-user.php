<?php
/**
 * promoimpresa 
 * Class User 
 * Class For Login, Register New User, Delete User, Get All Users data 
 * @since 1.0
*/

class User {
	
	// function construct	
	function __construct() {  
	
		// For delete Users, call user_delete function using do_action call by $.post()
		add_action( 'wp_ajax_delete_user', array( $this, 'user_delete' ) );
		
		// For deactive Users, call user_deactive function using do_action call by $.post()
		add_action( 'wp_ajax_deactive_user', array( $this, 'user_deactive' ) );
		
		// For active Users, call user_deactive function using do_action call by $.post()
		add_action( 'wp_ajax_active_user', array( $this, 'user_active' ) );
		
		// For check user tester or not
		add_action( 'wp_ajax_check_user_is_test', array( $this, 'user_is_test' ) );
	}
	
	// Checked Currenty User Login or Not If Not Then Redirect Login page	
	public function check_login() {
		
		global $menu_url;
		
		if( isset( $_SESSION['is_temp_user'] ) ) {
			
			@header("Location:" . SITE_URL . "/" . ( $menu_url["set_password"][LANG] ? $menu_url["set_password"][LANG] : $menu_url["set_password"]['it'] ) );  
			exit;
		}

		if( ! $_SESSION || ! $_SESSION['is_logged_user'] || ! $_SESSION['id'] ) {
			
			$_SESSION['login_redirect']	= "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];			
			$error_code[] = "101 : User Not Login";	

			@header('Location: '.SITE_URL . "/" . ( $menu_url["user_login"][LANG] ? $menu_url["user_login"][LANG] : $menu_url["user_login"]['it'] ) );
			exit;
		}
		
		return true;
	}
	
	
	// Checked current user profile update or not if not completed then redirec user profile update page
	public function check_user_complete_profile() {
		
		global $menu_url;
		
		$user_data = $this->get_userinfo();
		
		if ( $user_data->is_profile_completed == 0  &&  $_SESSION['is_logged_user'] &&   $_SESSION['id']){
	  
			$id = base64url_encode ( base64url_encode( base64url_encode( $user_data->id ) ) );
			@header("Location:" . SITE_URL . "/" . ( $menu_url["update_user_profile"][LANG] ? $menu_url["update_user_profile"][LANG] : $menu_url["update_user_profile"]['it'] ) . "/" . $id . "/profile" );
			exit; 
		}
		
		return true; 
	}
	
	
	
	/**
	 * Checked User Available or Not If Not Available then Register New User
	 *  
	 * @param array $args Handles Checking of data, User Name, User Email, User Password, Company Name                      
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function add_new_user( $user_data = array() ) {
		
		global $wpdb, $admin;	
		 
		if( ! $_POST['email'] )
			return false; 
		  
		$check_email  = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM users WHERE LOWER(email) = %s", trim( $_POST['email'] ) ) );
		
		if( ! $check_email ){			
			
			
			$email 				= strtolower( trim ( $_POST['email'] ) );	
			
			$social_data		= array(
									"web"	=> $_POST["web"],
									"linkedin"	=> $_POST["linkedin"],
									"facebook"	=> $_POST["facebook"],
									"twitter"	=> $_POST["twitter"],
									"google_plus"	=> $_POST["google_plus"],
									"instagram"	=> $_POST["instagram"],
								);
	 
	
			$social_data_serialize = serialize(  $social_data );
		 
			
			$user_data = array(						
							'cognome_ragione_sociale'		=> uc_words ( $_POST['cognome_ragione_sociale'] ),
							'nome'							=> uc_words ( $_POST['nome'] ),
							'studio_associato_id'			=> $_POST["studio_associato_id"],
							'paese_nazione_id'				=> $_POST["paese_nazione_id"],
							'citta_id'						=> $_POST["citta_id"],
							'categoria_professione_id'		=> $_POST["categoria_professione_id"],				
							'indirizzo'						=> $_POST["indirizzo"],
							'comune'						=> $_POST["comune"],
							'cap'							=> $_POST["cap"],
							'prov'							=> $_POST["prov"],
							'telefoni'						=> $_POST["telefoni"],
							'email'							=> $email,
							'social_data'					=> $social_data_serialize,
							'azienda'						=> $_POST["azienda"],
							'url_sito_azienda'				=> trim( $_POST["url_sito_azienda"] ),
							'partita_iva'					=> $_POST["partita_iva"],
							'codice_fiscale'				=> $_POST["codice_fiscale"],
							'pec'							=> $_POST["pec"],
							'iban'							=> $_POST["iban"],
							'created_at'					=> current_time(),
							'user_agent'					=> user_agent(),						
							'ip'			 				=> get_ip()	,
						);		
						
			$wpdb->insert( 'users', $user_data );	 
			$id = $wpdb->insert_id;
				
			/* if( $id ){
				
				$to				=  $user_mail;
			
				$mail_template	= 	file_get_contents( SITE_URL . '/assets/email_template.html' );			 
				$mail_template	=	str_replace( "{{{year}}}", date("Y"), $mail_template );		
				$mail_template	=	str_replace( "{{{etrp}}}", "", $mail_template );
				
				if( $_POST['user_language'] == "it" ){ 
					
					$subject			= 	$admin->get_admin_meta( 1, "it_user_reg_sub" );				
					$mail_body			= 	$admin->get_admin_meta( 1, "it_user_reg_body" ); 
					
					$mail_body			=	str_replace( "{{{first_name}}}", uc_words ( $_POST['user_first_name'] ), $mail_body );
					$mail_body			=	str_replace( "{{{last_name}}}", uc_words ( $_POST['user_last_name'] ), $mail_body );
					$mail_body			=	str_replace( "{{{user_password}}}", $_POST['user_password'], $mail_body );
					$mail_body			=	str_replace( "{{{timing}}}", view_current_time() , $mail_body ); 
			
					$mail_template		=	str_replace( "{{{title}}}", $subject, $mail_template );			
					$mail_template		=	str_replace( "{{{mail_body}}}", $mail_body, $mail_template );		 
					
					$email_send_from	= 	$admin->get_admin_meta( 1, "it_email_send_from" );
					$email_send_to		= 	$admin->get_admin_meta( 1, "it_email_send_to" ) . " " . $to;			
					$mail_template		=	str_replace( "{{{mail_send_by}}}", $email_send_from, $mail_template );
					$mail_template		=	str_replace( "{{{mail_send_to}}}", $email_send_to, $mail_template );
					
					$body 				= 	$mail_template;  
									
				} else {
					
					$subject			= 	$admin->get_admin_meta( 1, "en_user_reg_sub" );				
					$mail_body			= 	$admin->get_admin_meta( 1, "en_user_reg_body" ); 
					
					$mail_body			=	str_replace( "{{{first_name}}}", uc_words ( $_POST['user_first_name'] ), $mail_body );
					$mail_body			=	str_replace( "{{{last_name}}}", uc_words ( $_POST['user_last_name'] ), $mail_body );
					$mail_body			=	str_replace( "{{{user_password}}}", $_POST['user_password'], $mail_body );
					$mail_body			=	str_replace( "{{{timing}}}", view_current_time() , $mail_body ); 
			
					$mail_template		=	str_replace( "{{{title}}}", $subject, $mail_template );			
					$mail_template		=	str_replace( "{{{mail_body}}}", $mail_body, $mail_template );		 
					
					$email_send_from	= 	$admin->get_admin_meta( 1, "en_email_send_from" );
					$email_send_to		= 	$admin->get_admin_meta( 1, "en_email_send_to" ) . " " . $to;			
					$mail_template		=	str_replace( "{{{mail_send_by}}}", $email_send_from, $mail_template );
					$mail_template		=	str_replace( "{{{mail_send_to}}}", $email_send_to, $mail_template );
					
					$body 				= 	$mail_template;   
				}
				 
				
				// This is headers
				 
				$sender_name	= "Promoimpresa";
				$sender_email	= "noreply@promoimpresa.com";
				$return_email	= "noreply@promoimpresa.com";
				
				$headers 	 = "From: ".$sender_name." <".$sender_email.">" . "\r\n";
				$headers 	.= "Reply-To: ".$return_email."" . "\r\n";
				$headers 	.= "Return-Path: ".$return_email."\r\n";
				$headers  	.= "MIME-Version: 1.0\r\n";
				$headers 	.= "Content-type: text/html; charset: utf8\r\n";
				$headers 	.= "X-Mailer: PHP/" . phpversion()."\r\n";
				$headers 	.= "X-Priority: 1 (Highest)\n";
				$headers 	.= "X-MSMail-Priority: High\n";
				$headers 	.= "Importance: High\n";
				
	
				$attachments	= array();
				wp_mail( $to, $subject, $body, $headers, $attachments );  
				
				return true;
				
			}	  */
		}  
		
		$error_code[] = "103 : Registration Not Successfull";	
							     	    		
		return false;
	}
	
	
	
	// Get Current Loged User All Information using Object 

	public function get_userinfo( $id = "" ) {
		global $wpdb;
		
		if( ! $id )
			$id = $_SESSION['id']; 
		
		if( ! $id )
			return array();
			
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM users WHERE id = %d", $id ) );
	}
	
	/**
	 * Get All Users List
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function get_all_user_list( $user_status = 0  ) {
		
		global $wpdb;		
		
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM users WHERE user_status = '%d' ORDER BY `id` DESC", $user_status ) );
	}	
	
	/**
	 * Get Total Users List regtister today
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function total_register_users_today() {
		
		global $wpdb;		
		
		$wpdb->get_results( "SELECT  id FROM users WHERE user_created_at LIKE '%" . date("Y-m-d") . "%'" );	
		return 	$wpdb->num_rows;	
		
	}	
	
	
	/**
	 * Get Total Users List login today
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function total_login_users_today() {
		
		global $wpdb;		
		
		$wpdb->get_results( "SELECT id FROM users WHERE user_last_login LIKE '%" . date("Y-m-d") . "%'" );	
		return 	$wpdb->num_rows;	
		
	}	
	
	
	
	/**
	 * Get total android registered users today
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function total_register_android_users_today() {
		
		global $wpdb;		
		
		return $wpdb->get_var( "SELECT COUNT( id ) FROM users WHERE user_created_at LIKE '%" . date("Y-m-d") . "%' AND user_registration_by = 'Android'" );	
		 
	}	
	
	/**
	 * Get total iphone registered users today
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function total_register_iphone_users_today() {
		
		global $wpdb;		
		
		return $wpdb->get_var( "SELECT COUNT( id ) FROM users WHERE user_created_at LIKE '%" . date("Y-m-d") . "%' AND user_registration_by = 'Iphone'" );	
		 
		
	}
	
	/**
	 * Get total web registered users today
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function total_register_web_users_today() {
		
		global $wpdb;		
		
		return $wpdb->get_var( "SELECT COUNT( id ) FROM users WHERE user_created_at LIKE '%" . date("Y-m-d") . "%' AND user_registration_by = 'Web'" );	
		 
		
	}
	
		
	
	
	
	/**
	 * Get All Users Token List
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function get_selected_user_token_data( $id ) {
		
		if( ! $id )
			return false;
		
		global $wpdb;		
		
		return $wpdb->get_col( "SELECT android_device_token FROM user_login_token WHERE id = ".$id );
	}	
	
	/**
	 * Get All Users Token List
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function get_selected_user_ios_token_data( $id ) {
		
		if( ! $id )
			return false;
		
		global $wpdb;		
		
		return $wpdb->get_col( "SELECT iphone_device_token FROM user_login_token WHERE id = ".$id );
	}	
	
	
	
	
	/**
	 * Get All Users email List
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function get_all_user_email_list( $user_status = 0   ) {
		
		global $wpdb;		
		
		return $wpdb->get_results( $wpdb->prepare( "SELECT id, email FROM users WHERE user_status = %d  ORDER BY `id` DESC", $user_status ) );
	}	
	
	
	/**
	 * Get All Test Users email List
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function get_all_test_user_email_list( $user_status = 0 ,  $user_is_testing = 1 ) {
		
		global $wpdb;		
		
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM users WHERE user_status = %d AND user_is_active = %d AND user_is_testing = %d ORDER BY `id` DESC", $user_status,   $user_is_testing ) );
	}	
	
	
	/**
	 * Get All Users List
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function get_all_user_list_limited_data( $user_status = 0  ) {
		
		global $wpdb;		
		
		return $wpdb->get_results( $wpdb->prepare( "SELECT id, email, user_language, android_device_token, iphone_device_token FROM users WHERE user_status = %d", $user_status  ) );
	}		
	
	/**
	 * Get All Deactivated Users List
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function get_all_deactivate_user_list( $user_status = 0  , $is_active= 0) {
		
		global $wpdb;		
		
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM users WHERE user_status = '%d' ORDER BY `id` DESC", $user_status ) );
	}		
	
	
	/**
	 * Get All Information about Perticular Selected User
	 *  
	 * @param id 
	 *
	 * @return $userdata Array
	 * @since 1.0
	 */
	public function get_selected_user_data( $id = "" , $user_status = 0 ) {
		
		global $wpdb;		
		
		if( ! $id )
			return false;

		return	 $wpdb->get_row( $wpdb->prepare( "SELECT * FROM users WHERE id = %d AND user_status = '%d'", $id , $user_status ) );			
		
	}
	
	/**
	 * Get All Information about Perticular Selected User
	 *  
	 * @param id 
	 *
	 * @return $userdata Array
	 * @since 1.0
	 */
	public function get_selected_user_data_for_admin( $id = "" ) {
		
		global $wpdb;		
		
		if( ! $id )
			return false;

		return	 $wpdb->get_row( $wpdb->prepare( "SELECT * FROM users WHERE id = %d", $id ) );			
		
	}
	
	
	
	/**
	 * Get Users Full Name
	 *  
	 * @param id 
	 *
	 * @return result 
	 
	 * @since 1.0
	 */
	public function get_user_full_name( $id = ''  ) {
		
		global $wpdb;		
		
		$user_data = $wpdb->get_row( $wpdb->prepare( "SELECT user_first_name,user_last_name FROM users WHERE id = '%d'", $id ) );
		
		return $user_data->user_first_name." ".$user_data->user_last_name;
	}		
	
	 
	
	/**
	 * Checked User Available or Not If Available then make login process
	 *
	 * @param user_mail, user_pass Check data : Current Login Time, User Agent, IP Address  
	 *
	 * @return bool 
	 *  @since 1.0
	 */
	public function login( $user_mail , $user_pass , $user_status = 0   )  {
		
		global $wpdb, $error_code;
		
		unset( $_SESSION['is_temp_tipster'] );
		unset( $_SESSION['is_logged_tipster'] );
		unset( $_SESSION['tipster_id'] );
		
		if( ! $user_mail )
			return false;
			
		$user_pass = trim (  $user_pass );	

		$user  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM users WHERE LOWER(email) = %s AND user_status = '%d'", $user_mail , $user_status   ) );		
		
		if( $user->user_password == "" ) {
			
			unset($_SESSION['notification']);
			
			if( $user && ( $user->temp_password == $user_pass ) ) {	

			
				$_SESSION['is_temp_user']	= true;
				$_SESSION['is_logged_user']	= true;
				 
				$_SESSION['id']		= $user->id;
				
				$user_data = array(						
					'user_last_login' 		=> current_time(),
					'user_agent'			=> user_agent(),
					'ip' 					=> get_ip(),											
				);									
				
				$wpdb->update( 'users', $user_data, array( 'id' => $user->id ) ); 				
				return true;	
			}	


		} else if( $user && ( $user->user_password == md5( $user_pass . AUTH_SALT ) ) ) {							

				$_SESSION['is_logged_user']	= true;
				$_SESSION['id']		= $user->id;
				
				$user_data = array(						
					'user_last_login' 		=> current_time(),
					'user_agent'			=> user_agent(),
					'ip' 					=> get_ip(),											
				);	 
				
				$wpdb->update( 'users', $user_data, array( 'id' => $user->id ) ); 				
				
				return true;			
		}
		
		//do_action( "login_fail", $user_mail );
		
		$error_code[] = "102 : Login Not Successfull";	
					
		return false;        	    
	}	
	
	
	
	/**
	 * check user cart and add or update cart json table
	 *
	 * @param json_data
	 *
	 * @return bool 
	 *  @since 1.0
	 */
	public function update_user_cart_data( $cart_data = "" )  {
		
		global $wpdb;
		
		$id	=	$_SESSION['id'];
		
		if( ! $id )
			return false;
			
		$user_cart_data  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM users_cart WHERE cart_user_id = %d", $id ) );		
		
		if( $user_cart_data ) { 
			 
			$cart_data = array( 'cart_data'	=> $cart_data );					
			
			return $wpdb->update( 'users_cart', $cart_data, array( 'cart_user_id' => $id ) ); 				

		} else {								
 	 
			$cart_data = array(						
				'cart_user_id'		=> $id,
				'cart_data' 		=> $cart_data, 
			);		
				
			return $wpdb->insert( 'users_cart', $cart_data );	 
		}
		 
					
		return false;        	    
	}	
	
	

	
	
	
	/*******************************For Google Login*************************************/
	
	
	/**
	 * Checked User Available or Not 
	 *
	 * @param user_email_address
	 *
	 * @return bool 
	 *  @since 1.0
	 */
	public function check_user_exist_or_not( $user_email_address = '' , $arg = array() )   {
		
		global $wpdb, $admin;	
		
		if( !  $user_email_address  )
			return false; 
		
		$check_email  = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM users WHERE email = '%s' AND user_status = '%d' ", $user_email_address, 0) );
		
		if( $check_email ){ 
			
			$_SESSION['is_logged_user']	= true;
			$_SESSION['id']		= $check_email->id;
				
			$user_data = array(						
				'user_last_login' 		=> current_time(),
				'user_agent'			=> user_agent(),
				'ip' 					=> get_ip(),											
			);					
			
			$wpdb->update( 'users', $user_data, array( 'id' => $check_email->id ) ); 				
			
			return true;
			
		} else {
			
			$user_mail = strtolower( trim ( $arg['email'] ) );
			$temp_password = random_pass();			
			
			$user_city	 	= ( $arg['user_city'] ) ? $arg['user_city']: "" ;
			$user_sex	 	= ( $arg['user_sex'] ) ? $arg['user_sex']: "" ;
			$user_dob	 	= ( $arg['user_dob'] ) ? $arg['user_dob']: "" ;
			
			$user_data = array(						
				'user_first_name'			=> uc_words ( $arg['user_first_name'] ),
				'user_last_name'			=> uc_words ( $arg['user_last_name'] ),
				'email'				=> $user_mail,				
				'temp_password'	            => $temp_password,
				'user_register_from'		=> $arg['user_register_from'],
				'user_registration_by'		=> $arg['user_registration_by'],
				'user_first_time_login'		=> 1,				
				'is_profile_completed'	    => 0,
				'user_created_at'			=> current_time(),
				'user_agent'				=> user_agent(),						
				'ip'			 			=> get_ip()	,
			);		
				
			$wpdb->insert( 'users', $user_data );	
			$id =  $wpdb->insert_id; 
			
			if( $id ){
			
				$_SESSION['is_temp_user']	= true;
				$_SESSION['is_logged_user']	= true;
				$_SESSION['id']		= $id;
				
				$to			=  $user_mail;  
				
				$mail_template	= 	file_get_contents( SITE_URL . '/assets/email_template.html' );
				$mail_template	=	str_replace( "{{{year}}}", date("Y"), $mail_template );		
				$mail_template	=	str_replace( "{{{etrp}}}", "", $mail_template );
			
				if( LANG == "it" ){
					
					
					$subject		= 	$admin->get_admin_meta( 1, "it_user_social_reg_sub" );				
					$mail_body		= 	$admin->get_admin_meta( 1, "it_user_social_reg_body" ); 
						
					$mail_body		=	str_replace( "{{{first_name}}}", uc_words ( $arg['user_first_name'] ), $mail_body );
					$mail_body		=	str_replace( "{{{last_name}}}", uc_words ( $arg['user_last_name'] ), $mail_body );
					$mail_body		=	str_replace( "{{{user_password}}}", $temp_password, $mail_body );
					$mail_body		=	str_replace( "{{{timing}}}", view_current_time() , $mail_body ); 
			
					$mail_template	=	str_replace( "{{{title}}}", $subject, $mail_template );			
					$mail_template	=	str_replace( "{{{mail_body}}}", $mail_body, $mail_template );		 
					
					$email_send_from	= 	$admin->get_admin_meta( 1, "it_email_send_from" );
					$email_send_to		= 	$admin->get_admin_meta( 1, "it_email_send_to" ) . " " . $to;			
					$mail_template		=	str_replace( "{{{mail_send_by}}}", $email_send_from, $mail_template );
					$mail_template		=	str_replace( "{{{mail_send_to}}}", $email_send_to, $mail_template );
					
					$body 			= $mail_template;   
									
				} else {
					
					$subject		= 	$admin->get_admin_meta( 1, "en_user_social_reg_sub" );				
					$mail_body		= 	$admin->get_admin_meta( 1, "en_user_social_reg_body" ); 
						
					$mail_body		=	str_replace( "{{{first_name}}}", uc_words ( $arg['user_first_name'] ), $mail_body );
					$mail_body		=	str_replace( "{{{last_name}}}", uc_words ( $arg['user_last_name'] ), $mail_body );
					$mail_body		=	str_replace( "{{{user_password}}}", $temp_password, $mail_body );
					$mail_body		=	str_replace( "{{{timing}}}", view_current_time() , $mail_body ); 
			
					$mail_template	=	str_replace( "{{{title}}}", $subject, $mail_template );			
					$mail_template	=	str_replace( "{{{mail_body}}}", $mail_body, $mail_template );		 
					
					$email_send_from	= 	$admin->get_admin_meta( 1, "en_email_send_from" );
					$email_send_to		= 	$admin->get_admin_meta( 1, "en_email_send_to" ) . " " . $to;			
					$mail_template		=	str_replace( "{{{mail_send_by}}}", $email_send_from, $mail_template );
					$mail_template		=	str_replace( "{{{mail_send_to}}}", $email_send_to, $mail_template );
					
					$body 			= $mail_template;   
				}
			
			
				 
				
				// This is headers
				$sender_name	= "Promoimpresa";
				$sender_email	= "noreply@promoimpresa.com";
				$return_email	= "noreply@promoimpresa.com";
				
				$headers 	 = "From: ".$sender_name." <".$sender_email.">" . "\r\n";
				$headers 	.= "Reply-To: ".$return_email."" . "\r\n";
				$headers 	.= "Return-Path: ".$return_email."\r\n";
				$headers  	.= "MIME-Version: 1.0\r\n";
				$headers 	.= "Content-type: text/html; charset: utf8\r\n";
				$headers 	.= "X-Mailer: PHP/" . phpversion()."\r\n";
				$headers 	.= "X-Priority: 1 (Highest)\n";
				$headers 	.= "X-MSMail-Priority: High\n";
				$headers 	.= "Importance: High\n";
				
				 
				$attachments	= array();
				wp_mail( $to, $subject, $body, $headers, $attachments ); 
				
				return true;
			}
			
			return false;
			
		}
		
	}
	
 
	
	/**
	 * Update User Profile 
	 *  
	 * @param array $profile_args , array $other_options_arg Handles All Requested parameter data Of Users
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function update_user_profile( $user_data = array() ) {
		
		global $wpdb;		 
				
		if( $_POST ) {
			
			$user_dob  = date2mysql ( $_POST['user_dob'], true );
			
			$other_desc = "";
			if( $_POST['user_other'] ) { $other_desc =  $_POST['user_other']; } 
			
			
			$user_data = array(						
				'user_first_name'			=> uc_words ( $_POST['user_first_name'] ),
				'user_last_name'			=> uc_words ( $_POST['user_last_name'] ),				
				'user_mobile'				=> $_POST['user_mobile'],				
				'user_dob'					=> $user_dob,
				'user_sex'					=> $_POST['user_sex'],				
				'user_country'				=> $_POST['user_country'],				
				'user_city'					=> $_POST['user_city'],				
				'user_address'				=> $_POST['user_address'],				
				'user_favorite_sport'		=> $_POST['user_favorite_sport'],				
				'user_about_our_site'		=> $_POST['user_about_our_site'],				
				'user_affiliate_code'		=> $_POST['user_affiliate_code'],
				'user_other_desc'			=> $other_desc,								
				'user_language'	            => $_POST['user_language'],
				'is_profile_completed'		=> 1,
				'user_updated_at'			=> current_time(),
				'user_agent'				=> user_agent(),						
				'ip'			 			=> get_ip()	,
			);	 	
			
			if( ! empty( $_POST['user_password'] ) ) {
				
				$user_data['user_password']	= md5( trim( $_POST['user_password'] . AUTH_SALT ) ); 	
			} 	
			
			if( $_POST['email'] ){
				
				$email  = strtolower( trim ( $_POST['email'] ) );
				
				$check_email  = $wpdb->get_row( $wpdb->prepare( "SELECT id, email FROM users WHERE email = '%s' AND id != %d", $email, $_POST['id'] ) );
				
				if( ! $check_email ){
										
					$user_data['email']	=  $email;
					
				}
			}
			
			
			$wpdb->update( 'users', $user_data, array( 'id' => $_POST['id'] ) );  
			
			
			if( $_FILES['user_profile_pic']['name'] ) {
				
				$sourcefile		= $_FILES['user_profile_pic']['tmp_name'];
				$file_name 		= $_FILES['user_profile_pic']['name'];
				$extension 		= strtolower( end( explode( ".", $file_name ) ) );
				$new_file_name	= "promoimpresa_user_".md5( time().rand(111,999) ).".".$extension;
				$endfile		= SITE_DIR . '/uploads/users/'.$new_file_name;
				$type			= $_FILES['user_profile_pic']['type'];
				
				$uploaded  = makeThumbnail($sourcefile, $max_width=300, $max_height=300, $endfile, $type);
			}	
			
			if( isset( $uploaded ) ) {			
				
				$old_pic = $wpdb->get_row( $wpdb->prepare( "SELECT user_profile_pic FROM users WHERE id = %d ", $_POST['id'] ) );							
				unlink( SITE_DIR . "/uploads/users/".$old_pic->user_profile_pic);				
				
				$wpdb->update('users', array( 'user_profile_pic' => $new_file_name ), array( 'id' => $_POST['id'] ) ); 				
			} 
			 
			return true;			
		}  		
			 	    		
		return false;
	}
	 
	
	/**
	 * Checked Email User Available or Not If  Available then Send Mail
	 *  
	 * @param str $user_mail Handles Checking of data, User Email
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function forgot_password( $user_mail = "" ) {
		
		if( ! $user_mail )
			return false;
			
		 global $wpdb, $admin;		 
		
		 $check_email  = $wpdb->get_row( $wpdb->prepare( "SELECT id, email, user_first_name, user_last_name, user_language FROM users WHERE LOWER(email) = %s  ", $user_mail  ) );
		
		if( $check_email ){			

			$key =  md5 ( rand(1,100) . $check_email->id . AUTH_SALT );
			
			$user_data = array(						
				'reset_password_key'	=> $key,											
				'ip'			 		=> get_ip(),
				'user_agent'			=> user_agent(),				
			);	 				

			$wpdb->update( 'users', $user_data, array( 'id' => $check_email->id ) );  
			
			$to				= 	$check_email->email;	
			
			$mail_template	= 	file_get_contents( SITE_URL . '/assets/email_template.html' );
			$mail_template	=	str_replace( "{{{year}}}", date("Y"), $mail_template );		
			$mail_template	=	str_replace( "{{{etrp}}}", "", $mail_template );		
			
			if( $check_email->user_language == "it" ){
				
				$subject	= $admin->get_admin_meta( 1, "it_forgot_pw_sub" );														
				
				$link 		= SITE_URL . '/utente/user-ripristina-password/'.$key;	
				
				$mail_body	= $admin->get_admin_meta( 1, "it_forgot_pw_body" ); 
				
				$mail_body	=	str_replace( "{{{first_name}}}", uc_words ( $check_email->user_first_name ), $mail_body );
				$mail_body	=	str_replace( "{{{last_name}}}", uc_words ( $check_email->user_last_name ), $mail_body );
				$mail_body	=	str_replace( "{{{link}}}", $link, $mail_body );
				$mail_body	=	str_replace( "{{{timing}}}", view_current_time() , $mail_body ); 
		
				$mail_template	=	str_replace( "{{{title}}}", $subject, $mail_template );			
				$mail_template	=	str_replace( "{{{mail_body}}}", $mail_body, $mail_template );		 
				
				$email_send_from	= 	$admin->get_admin_meta( 1, "it_email_send_from" );
				$email_send_to		= 	$admin->get_admin_meta( 1, "it_email_send_to" ) . " " . $to;			
				$mail_template		=	str_replace( "{{{mail_send_by}}}", $email_send_from, $mail_template );
				$mail_template		=	str_replace( "{{{mail_send_to}}}", $email_send_to, $mail_template );
				
				$body 			= $mail_template;
					
			} else { 
			
				$subject	= $admin->get_admin_meta( 1, "en_forgot_pw_sub" );		 
				
				$link 		= SITE_URL . '/users/user-reset-password/'.$key;					
				
				$mail_body	= $admin->get_admin_meta( 1, "en_forgot_pw_body" ); 
				
				$mail_body	=	str_replace( "{{{first_name}}}", uc_words ( $check_email->user_first_name ), $mail_body );
				$mail_body	=	str_replace( "{{{last_name}}}", uc_words ( $check_email->user_last_name ), $mail_body );
				$mail_body	=	str_replace( "{{{link}}}", $link, $mail_body );
				$mail_body	=	str_replace( "{{{timing}}}", view_current_time() , $mail_body );  
		
				$mail_template	=	str_replace( "{{{title}}}", $subject, $mail_template );			
				$mail_template	=	str_replace( "{{{mail_body}}}", $mail_body, $mail_template );		 
				
				$email_send_from	= 	$admin->get_admin_meta( 1, "en_email_send_from" );
				$email_send_to		= 	$admin->get_admin_meta( 1, "en_email_send_to" ) . " " . $to;			
				$mail_template		=	str_replace( "{{{mail_send_by}}}", $email_send_from, $mail_template );
				$mail_template		=	str_replace( "{{{mail_send_to}}}", $email_send_to, $mail_template );
				
				$body 		= $mail_template;
								 
				 	
			}
			 	 
			    // This is headers
				$sender_name	= "Promoimpresa";
				$sender_email	= "noreply@promoimpresa.com";
				$return_email	= "noreply@promoimpresa.com";
				
				$headers 	 = "From: ".$sender_name." <".$sender_email.">" . "\r\n";
				$headers 	.= "Reply-To: ".$return_email."" . "\r\n";
				$headers 	.= "Return-Path: ".$return_email."\r\n";
				$headers  	.= "MIME-Version: 1.0\r\n";
				$headers 	.= "Content-type: text/html; charset: utf8\r\n";
				$headers 	.= "X-Mailer: PHP/" . phpversion()."\r\n";
				$headers 	.= "X-Priority: 1 (Highest)\n";
				$headers 	.= "X-MSMail-Priority: High\n";
				$headers 	.= "Importance: High\n";
				
				$attachments	= array();
				
				return	wp_mail( $to, $subject, $body, $headers, $attachments ); 
		}  
		
		$error_code[] = "104 : Registration Not Successfull";		
				  	    		
		return false;
	}
	
	/**
	 *  Reset Password If User Exists
	 *  
	 * @param $user_password, $id for Update new password
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function reset_password( $user_password = "",  $id = "" ) {
		
		$user_password 	= $_POST['user_password'];
		$password_key	= $_POST['password_key'];
			
		if( ! $password_key  || ! $user_password )
			return false;
			
		global $wpdb, $admin;		 
		
		$check_user  = $wpdb->get_row( $wpdb->prepare( "SELECT  id, email, user_first_name, user_last_name, user_language FROM users WHERE reset_password_key = %s", $password_key ) );
		
		if( $check_user ){			
		
			$new_password	=	 md5( trim( $user_password . AUTH_SALT ) );
					
			$user_data = array(						
				'user_password'			=> $new_password,							
				'reset_password_key'	=> '',
				'user_updated_at'		=> current_time(),
				'ip'			 		=> get_ip(),
				'user_agent'			=> user_agent(),						
			);	 				

			$wpdb->update( 'users', $user_data,  array( 'id' => $check_user->id ) );
			
			$to			= $check_user->email;
			
			$mail_template	= 	file_get_contents( SITE_URL . '/assets/email_template.html' );
			$mail_template	=	str_replace( "{{{year}}}", date("Y"), $mail_template );		
			$mail_template	=	str_replace( "{{{etrp}}}", "", $mail_template );
			
			if( $check_user->user_language == "it" ){
				
				$subject	= 	$admin->get_admin_meta( 1, "it_reset_pw_sub" );				
				$mail_body	= 	$admin->get_admin_meta( 1, "it_reset_pw_body" ); 
				
				$mail_body	=	str_replace( "{{{first_name}}}", uc_words ( $check_user->user_first_name ), $mail_body );
				$mail_body	=	str_replace( "{{{last_name}}}", uc_words ( $check_user->user_last_name ), $mail_body );
				$mail_body	=	str_replace( "{{{timing}}}", view_current_time() , $mail_body ); 
		
				$mail_template	=	str_replace( "{{{title}}}", $subject, $mail_template );			
				$mail_template	=	str_replace( "{{{mail_body}}}", $mail_body, $mail_template );		 
				
				$email_send_from	= 	$admin->get_admin_meta( 1, "it_email_send_from" );
				$email_send_to		= 	$admin->get_admin_meta( 1, "it_email_send_to" ) . " " . $to;			
				$mail_template		=	str_replace( "{{{mail_send_by}}}", $email_send_from, $mail_template );
				$mail_template		=	str_replace( "{{{mail_send_to}}}", $email_send_to, $mail_template );
				
				$body 			= $mail_template;   
				
				 
				
			} else {
				
				$subject	= 	$admin->get_admin_meta( 1, "en_reset_pw_sub" );				
				$mail_body	= 	$admin->get_admin_meta( 1, "en_reset_pw_body" ); 
				
				$mail_body	=	str_replace( "{{{first_name}}}", uc_words ( $check_user->user_first_name ), $mail_body );
				$mail_body	=	str_replace( "{{{last_name}}}", uc_words ( $check_user->user_last_name ), $mail_body );
				$mail_body	=	str_replace( "{{{timing}}}", view_current_time() , $mail_body ); 
		
				$mail_template	=	str_replace( "{{{title}}}", $subject, $mail_template );			
				$mail_template	=	str_replace( "{{{mail_body}}}", $mail_body, $mail_template );		 
				
				$email_send_from	= 	$admin->get_admin_meta( 1, "en_email_send_from" );
				$email_send_to		= 	$admin->get_admin_meta( 1, "en_email_send_to" ) . " " . $to;			
				$mail_template		=	str_replace( "{{{mail_send_by}}}", $email_send_from, $mail_template );
				$mail_template		=	str_replace( "{{{mail_send_to}}}", $email_send_to, $mail_template );
				
				$body 			= $mail_template; 
				
			}
			
			 
			
			// This is headers
			$sender_name	= "Promoimpresa";
			$sender_email	= "noreply@promoimpresa.com";
			$return_email	= "noreply@promoimpresa.com";
			
			$headers 	 = "From: ".$sender_name." <".$sender_email.">" . "\r\n";
			$headers 	.= "Reply-To: ".$return_email."" . "\r\n";
			$headers 	.= "Return-Path: ".$return_email."\r\n";
			$headers  	.= "MIME-Version: 1.0\r\n";
			$headers 	.= "Content-type: text/html; charset: utf8\r\n";
			$headers 	.= "X-Mailer: PHP/" . phpversion()."\r\n";
			$headers 	.= "X-Priority: 1 (Highest)\n";
			$headers 	.= "X-MSMail-Priority: High\n";
			$headers 	.= "Importance: High\n";
			
			 
			$attachments	= array();
			wp_mail( $to, $subject, $body, $headers, $attachments ); 
			
			return true;
		}  
		
		$error_code[] = "104 : Password Not Changed";		
				  	    		
		return false;
	}
	
	 
	
	   
	/**
	 * Make Log Out Process
	 *  
	 * @param SESSION ID Handles To Destroy Perticular SESSION
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function logout() {
		
        //session_destroy();        
		session_start();
		session_unset();
		unset( $_SESSION['id'] );
		unset( $_SESSION['is_logged_user'] );		
    	$_SESSION['FBID'] = NULL;
    	$_SESSION['FULLNAME'] = NULL;
    	$_SESSION['EMAIL'] =  NULL;

		return true;
   	} 
	
	
	
	
	/**
	 * For check users any package active or not
	 *  
	 * @param id 
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	 
	public function check_user_package_status( $id = '', $pos_subscribe_status = 'active' ) {

		global $wpdb;
		
		if( ! $id ) {	return false; 	}
		
		$total_data	=  $wpdb->get_results( $wpdb->prepare( "SELECT * FROM package_order_subscribe WHERE  pos_user_id = %d AND pos_subscribe_status = %s ", $id, $pos_subscribe_status ));
		return $wpdb->num_rows;
	} 
	
	/**
	 * For check users take package or not any time
	 *  
	 * @param id 
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	 
	public function check_user_subscribe_package_status( $id = '' ) {

		global $wpdb;
		
		if( ! $id ) {	return false; 	}
		
		$total_data	=  $wpdb->get_results( $wpdb->prepare( "SELECT * FROM package_order_subscribe WHERE  pos_user_id = %d AND pos_subscribe_status != '%s' ", $id, "pending"  ));
		return $wpdb->num_rows;
	} 
	
	
	/**
	 * For get last payment package type
	 *  
	 * @param id 
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	 
	public function get_user_last_payment_method( $id = '' ) {

		global $wpdb;
		
		if( ! $id ) {	return false; 	}
		
		return 	$wpdb->get_var( $wpdb->prepare( "SELECT pos_payment_method FROM package_order_subscribe WHERE  pos_user_id = %d AND pos_subscribe_status = '%s' ", $id, "active"  )); 
		 
	} 
	
	 
	/**
	 * Delete Perticular Selected User 
	 *  
	 * @param id Handles To delete User to match id 
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function user_delete( $id = '' ) {		
		
		if( ! $id && ! $_POST['id'] )
			return false;
		
		global $wpdb;
		
		$id  =  isset( $_POST['id'] ) ? $_POST['id'] : $id ;

		$wpdb->update( 'users', array( 'user_status' => 1, 'login_token' => '' ), array( 'id' => $id ) ); 								
		
		return true;
   	}
	
	 /**
	 * Approve Or Not Approve Perticular Member
	 *  
	 * @param id Handles To delete Member to match id 
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function user_approve( $id = '' , $is_approve = '' ) {		
		
		if( ! $id && ! $_POST['id'] )
			return false;
		
		global $wpdb;
		
		$id  =  isset( $_POST['id'] ) ? $_POST['id'] : $id ;

		$wpdb->update( 'users', array( 'login_token' => ''  ), array( 'id' => $id ) ); 								
		
		return true;
   	}
	
	
	 /**
	 * set user test or not
	 *  
	 * @param id Handles To delete Member to match id 
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function user_is_test( $id = '' , $test_user = '' ) {	
	 	 
		
		if( ! $_POST['id']  )
			return false;
		
		global $wpdb;
		
		$id  =  isset( $_POST['id'] ) ? $_POST['id'] : $id ;

		$wpdb->update( 'users', array( 'user_is_testing' => $_POST['test_user'] ), array( 'id' => $id ) ); 								
		
		return true;
   	}
	
	


   	// Set New Password and Delete Temporary Password for Users
   	public function update_user_password( $user_data = array()  ) {	
   		
		global $wpdb, $admin;
		
		if( $_POST ) {
			
			$user_dob  = date2mysql ( $_POST['user_dob'], true );
			$id   = $_POST['id'];
			 	
			$user_data = array(						
				'user_password'				=> md5( trim( $_POST['user_password'] . AUTH_SALT ) ), 	
				'temp_password'				=> "", 	
				'user_mobile'				=> $_POST['user_mobile'],				
				'user_dob'					=> $user_dob,
				'user_sex'					=> $_POST['user_sex'],				
				'user_country'				=> $_POST['user_country'],				
				'user_city'					=> $_POST['user_city'],				
				'user_address'				=> $_POST['user_address'],				
				'user_favorite_sport'		=> $_POST['user_favorite_sport'],				
				'user_updated_at'			=> current_time(),
				'user_agent'				=> user_agent(),						
				'ip'			 			=> get_ip()	,
			);			
		 
			$wpdb->update( 'users', $user_data, array( 'id' => $id ) );  	
			
			
			if($_FILES['user_profile_pic']['name']) {
				
				$sourcefile		= $_FILES['user_profile_pic']['tmp_name'];
				$file_name 		= $_FILES['user_profile_pic']['name'];
				$extension 		= strtolower( end( explode( ".", $file_name ) ) );
				$new_file_name	= "promoimpresa_user_".md5( time().rand(111,999) ).".".$extension;
				$endfile		= SITE_DIR . '/uploads/users/'.$new_file_name;
				$type			= $_FILES['user_profile_pic']['type'];
				
				$uploaded  = makeThumbnail($sourcefile, $max_width=300, $max_height=300, $endfile, $type);
			}	
			
			if( isset( $uploaded ) ) {			
				
				$old_pic = $wpdb->get_row( $wpdb->prepare( "SELECT user_profile_pic FROM users WHERE id = %d ", $_POST['id'] ) );							
				unlink( SITE_DIR . "/uploads/users/".$old_pic->user_profile_pic);				
				
				$wpdb->update('users', array( 'user_profile_pic' => $new_file_name ), array( 'id' => $_POST['id'] ) ); 				
			} 
			
			
			unset($_SESSION['is_temp_user']);
			
			$_SESSION['is_logged_user']	= true;
			$_SESSION['id']= $id; 
			
			$user_data  = $wpdb->get_row( $wpdb->prepare( "SELECT email, user_first_name, user_last_name  FROM users WHERE id = %d AND user_status", $id, 0) );
			
			$to				= 	$user_data->email;
			
			$mail_template	= 	file_get_contents( SITE_URL . '/assets/email_template.html' );
			$mail_template	=	str_replace( "{{{year}}}", date("Y"), $mail_template );		
			$mail_template	=	str_replace( "{{{etrp}}}", "", $mail_template );
			
			if( LANG == "it" ){
				
				
				$subject	= 	$admin->get_admin_meta( 1, "it_reset_pw_sub" );				
				$mail_body	= 	$admin->get_admin_meta( 1, "it_reset_pw_body" ); 
				
				$mail_body	=	str_replace( "{{{first_name}}}", uc_words ( $check_user->user_first_name ), $mail_body );
				$mail_body	=	str_replace( "{{{last_name}}}", uc_words ( $check_user->user_last_name ), $mail_body );
				$mail_body	=	str_replace( "{{{timing}}}", view_current_time() , $mail_body ); 
		
				$mail_template	=	str_replace( "{{{title}}}", $subject, $mail_template );			
				$mail_template	=	str_replace( "{{{mail_body}}}", $mail_body, $mail_template );		 
				
				$email_send_from	= 	$admin->get_admin_meta( 1, "it_email_send_from" );
				$email_send_to		= 	$admin->get_admin_meta( 1, "it_email_send_to" ) . " " . $to;			
				$mail_template		=	str_replace( "{{{mail_send_by}}}", $email_send_from, $mail_template );
				$mail_template		=	str_replace( "{{{mail_send_to}}}", $email_send_to, $mail_template );
				
				$body 			= $mail_template;   
				
			} else {
				
				$subject	= 	$admin->get_admin_meta( 1, "en_reset_pw_sub" );				
				$mail_body	= 	$admin->get_admin_meta( 1, "en_reset_pw_body" ); 
				
				$mail_body	=	str_replace( "{{{first_name}}}", uc_words ( $check_user->user_first_name ), $mail_body );
				$mail_body	=	str_replace( "{{{last_name}}}", uc_words ( $check_user->user_last_name ), $mail_body );
				$mail_body	=	str_replace( "{{{timing}}}", view_current_time() , $mail_body ); 
		
				$mail_template	=	str_replace( "{{{title}}}", $subject, $mail_template );			
				$mail_template	=	str_replace( "{{{mail_body}}}", $mail_body, $mail_template );		 
				
				$email_send_from	= 	$admin->get_admin_meta( 1, "en_email_send_from" );
				$email_send_to		= 	$admin->get_admin_meta( 1, "en_email_send_to" ) . " " . $to;			
				$mail_template		=	str_replace( "{{{mail_send_by}}}", $email_send_from, $mail_template );
				$mail_template		=	str_replace( "{{{mail_send_to}}}", $email_send_to, $mail_template );
				
				$body 			= $mail_template;    
				 
			}
			 
			// This is headers
			$sender_name	= "Promoimpresa";
			$sender_email	= "noreply@promoimpresa.com";
			$return_email	= "noreply@promoimpresa.com";
			
			$headers 	 = "From: ".$sender_name." <".$sender_email.">" . "\r\n";
			$headers 	.= "Reply-To: ".$return_email."" . "\r\n";
			$headers 	.= "Return-Path: ".$return_email."\r\n";
			$headers  	.= "MIME-Version: 1.0\r\n";
			$headers 	.= "Content-type: text/html; charset: utf8\r\n";
			$headers 	.= "X-Mailer: PHP/" . phpversion()."\r\n";
			$headers 	.= "X-Priority: 1 (Highest)\n";
			$headers 	.= "X-MSMail-Priority: High\n";
			$headers 	.= "Importance: High\n";
			

			$attachments	= array();
			wp_mail( $to, $subject, $body, $headers, $attachments );
			
			return true;
			
		}
		
		return false; 		 
   		
   	} 
	
	 
	
} 