<?php
/**
 * promoimpresa 
 * Class Admin 
 * Class For Admin Login And Manage All Modual
 * @since 1.0
*/

class Admin {
	
	// function construct	
	function __construct() {  
		
		// For delete Users, call user_delete function using do_action call by $.post()
		add_action( 'wp_ajax_delete_admin_user', array( $this, 'admin_user_delete' ) );
		
		
		// For send email to users in web/android/iphon users list
		add_action( 'wp_ajax_send_user_email', array( $this, 'send_user_email' ) );
		
		
	}
	
	// Checked Currenty Admin Login or Not If Not Then Redirect Login page	
	public function check_login() {
		if( ! $_SESSION || ! $_SESSION['is_admin_logged_id'] || ! $_SESSION['admin_id'] ) {
			
			$_SESSION['login_redirect']	= "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];			
			$error_code[] = "101 : Admin Not Login";			

			@ header('Location: '.SITE_URL.'/admin/login.php');
			exit;
		}
		
		return true;
	}
	
	// Get All Information About Current Loged Admin

	public function get_admininfo( $admin_id = "" ) {
		global $wpdb;
		
		if( ! $admin_id )
			$admin_id = $_SESSION['admin_id']; 
		
		if( ! $admin_id )
			return array();
			
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM admin WHERE admin_id = %d", $admin_id ) );
	}
	
	
	public function check_for_page_access( $page_access, $status = false ){
	
		global $wpdb, $admin;	
		
		$admin_role	= $admin->get_admininfo()->admin_role ;
		
		if( $status == true ){		
							
			if( $admin_role && strpos( $admin->get_selected_role_data( $admin_role )->role_page_access, $page_access ) === false ){
				return true;
			}
			
			return false;				
			
		} else {
			
			if (  $admin_role == 0 || strpos( $admin->get_selected_role_data( $admin_role )->role_page_access, $page_access ) !== $status ) { 
				return true;
			} 
			
			return false;		
		}
		 
	}
	
	
	
	
	 
		
	
	/**
	 * Checked Admin Available or Not If Available then make login process
	 *
	 * @param admin_mail, admin_pass 
	 * @return bool 
	 *  @since 1.0
	 */
	public function login( $admin_mail , $admin_pass , $admin_status = 0 )  {
		
		global $wpdb,  $error_code; 

		$admin  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM admin WHERE LOWER(admin_email) = %s AND admin_status = '%d'", $admin_mail , $admin_status ) );		
		
		if( $admin && ( $admin->admin_password == md5( $admin_pass . AUTH_SALT ) ) ) {						
				
				$_SESSION['is_admin_logged_id']	= true;
				$_SESSION['admin_id']		= $admin->admin_id;
				
				$admin_data = array(											
					'admin_agent'			=> user_agent(),
					'ip' 					=> get_ip(),											
				);					
				
				$wpdb->update( 'admin', $admin_data, array( 'admin_id' => $admin->admin_id ) ); 				
				
				return true;			
		}
		
		//do_action( "login_fail", $admin_mail );
		
		$error_code[] = "102 : Login Not Successfull";	
					
		return false;        	    
	}	
	 
	
	/**
	 * Checked Email Admin Available or Not If  Available then Send Mail
	 *  
	 * @param str $admin_mail Handles Checking of data, Admin Email
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function forgot_password( $admin_mail = "" ) {
		
		if( ! $admin_mail )
			return false;
			
		global $wpdb;		 
		
		$check_email  = $wpdb->get_row( $wpdb->prepare( "SELECT admin_id FROM admin WHERE LOWER(admin_email) = %s", $admin_mail ) );
		
		if( $check_email ){			

			$key =  md5 ( rand(1,100) . $check_email->admin_id . AUTH_SALT );
			
			$admin_data = array(						
				'reset_password_key'	=> $key,											
				'ip'			 		=> get_ip(),
				'admin_agent'			=> user_agent(),				
			);	 				

			$wpdb->update( 'admin', $admin_data, array( 'admin_id' => $check_email->admin_id ) );
			
			$to			= $admin_mail;
			$subject	= "Reset Password Link";			
     		$link 		= SITE_URL . '/reset_password.php?arg='.$key;					 
			
			
			$mail_body	=	"Reset Password Link Is : ".$link.".<br/><br/>
						
							Best regards,<br/>
							Promoimpresa Team<br/><br/>
									
							Please do not reply directly to this email, if you have any questions, you are invited to contact us at the email support@promoimpresa.com or to visit the section 'Questions (FAQ)'.<br/>			
							EMAIL RECEIVED on: ".view_current_time();
							
			$mail_template	= 	file_get_contents( SITE_URL . '/assets/email_template.html' );
			$mail_template	=	str_replace( "{{{year}}}", date("Y"), $mail_template );		
			$mail_template	=	str_replace( "{{{etrp}}}", "", $mail_template );
			$mail_template	=	str_replace( "{{{title}}}", "Reset Password Link", $mail_template );			
			$mail_template	=	str_replace( "{{{mail_body}}}", $mail_body, $mail_template );
			
			$email_send_from	= 	$admin->get_admin_meta( 1, "en_email_send_from" );
			$email_send_to		= 	$admin->get_admin_meta( 1, "en_email_send_to" ) . " " . $to;			
			$mail_template		=	str_replace( "{{{mail_send_by}}}", $email_send_from, $mail_template );
			$mail_template		=	str_replace( "{{{mail_send_to}}}", $email_send_to, $mail_template );
			
			$body 		= $mail_template;								
			
			// This is headers
			$sender_name	= "promoimpresa";
			$sender_email	= "noreply@promoimpresa.com";
			$return_email	= "noreply@promoimpresa.com";
		
			$headers 	 = "From: ".$sender_name." <".$sender_email.">" . "\r\n";
			$headers 	.= "Reply-To: ".$return_email."" . "\r\n";
			$headers 	.= "Return-Path: ".$return_email."\r\n";
			$headers  	.= "MIME-Version: 1.0\r\n";
			$headers 	.= "Content-type: text/html; charset: utf8\r\n";
			$headers 	.= "X-Mailer: PHP/" . phpversion()."\r\n";
			$headers 	.= "X-Priority: 1 (Highest)\n";
			$headers 	.= "X-MSMail-Priority: High\n";
			$headers 	.= "Importance: High\n";
			$attachments	= array();
			
			return wp_mail( $to, $subject, $body, $headers, $attachments );			
		}  
		
		$error_code[] = "104 : Registration Not Successfull";		
				  	    		
		return false;
	}
	
	/**
	 *  Reset Password If Admin Exists
	 *  
	 * @param $admin_password, $admin_id for Update new password
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function reset_password( $admin_password = "",  $admin_id = "" ) {
		
		$admin_password 	= $_POST['admin_password'];
		$password_key	= $_POST['password_key'];
			
		if( ! $password_key  || ! $admin_password )
			return false;
			
		global $wpdb;		 
		
		$check_admin  = $wpdb->get_row( $wpdb->prepare( "SELECT admin_id FROM admin WHERE reset_password_key = %s", $password_key ) );
		
		if( $check_admin ){			
		
			$new_password	=	 md5( trim( $admin_password . AUTH_SALT ) );
					
			$admin_data = array(						
				'admin_password'			=> $new_password,							
				'reset_password_key'	=> '',
				'admin_updated_at'		=> current_time(),
				'ip'			 		=> get_ip(),
				'admin_agent'			=> user_agent(),						
			);	 				

			$wpdb->update( 'admin', $admin_data,  array( 'admin_id' => $check_admin->admin_id ) );
			
			return true;			
		}  
		
		$error_code[] = "104 : Password Not Changed";		
				  	    		
		return false;
	}
	
	 
	/**
	 * Make Log Out Process
	 *  
	 * @param SESSION ID Handles To Destroy Perticular SESSION
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function logout() {
		
        //session_destroy();        
		session_start();
		session_unset();
		unset( $_SESSION['admin_id'] );
		unset( $_SESSION['is_admin_logged_id'] );		

		return true;
   	} 	
	
	
	 
	
	/**
	* Update user list privacy for listing perpose
	*  
	* @param  user_list_privacy
	*
	* @return result Object
	
	* @since 1.0
	*/
	public function update_user_list_privacy( $privacy_data = array() ){		
		
		global $wpdb;		
		
		
		$user_list_privacy = json_encode( $privacy_data['user_list_privacy'] );			
		
		 
		return $this->update_admin_meta( 1, 'user_list_privacy', $user_list_privacy );  
	}
	
	 
	
	/*********** Color Code Manage  ************/
	
	
	
 	/**
	 * To Add New Unique Color Code
	 *  
	 * @param color_data                  
	 *
	 * @return bool 	 
	 * @since 1.0
	 */ 
	public function add_color_code( $color_data = '' ) {
		
		global $wpdb;
		
		if( ! $_POST["color_name"] )
			return;		
		
		$color_name	=	ucwords( strtolower( trim( $_POST["color_name"] ) ) );		
		$color_code	=	trim( $_POST["color_code"] );		
		
		$check_color_code  = $wpdb->get_row( $wpdb->prepare( "SELECT color_id FROM color_code WHERE color_name = '%s' OR color_code = '%s'", $color_name, $color_code ) );
		
		if( ! $check_color_code ){
			
			$color_data	=	array(				
				"color_name"   			=> $color_name,			
				"color_code"   			=> trim( $_POST["color_code"] ),							
				'color_created_at' 		=> current_time(),
				'ip'               		=> get_ip(),
			);		

			return $wpdb->insert( 'color_code', $color_data );
		}
	
		return false;
	
	}
	
	
	/**
	 * Get All Color Code List
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function get_all_color_list( $color_status = 0  ) {
		
		global $wpdb;		
		
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM color_code WHERE color_status = %d ORDER BY `color_name` ASC", $color_status ) );
	}	
	
	
	/**
	 * Get All Information about Perticular Selected Color code
	 *
	 * @return $color_data Array
	 * @since 1.0
	 */
	public function get_selected_color_data( $color_id , $color_status = 0 ) {
		
		global $wpdb;		
		
		if( ! $color_id )
			return false;

		return	 $wpdb->get_row( $wpdb->prepare( "SELECT * FROM color_code WHERE color_id = %d AND color_status = %d", $color_id, $color_status ) );			
		
	} 
	
	
	/**
	 * Get All Information about Perticular Selected Color code for user id
	 *
	 * @return $color_data Array
	 * @since 1.0
	 */
	public function get_color_data_for_user( $user_id , $status = 0 ) {
		
		global $wpdb;		
		
		if( ! $user_id )
			return false;
			
		$color_id	=	$wpdb->get_var( $wpdb->prepare( "SELECT  color_id FROM admin WHERE admin_id = %d AND admin_status = %d", $user_id, $status ) );				
		
		if( $color_id > 0 )	{
			
			return	 $wpdb->get_row( $wpdb->prepare( "SELECT * FROM color_code WHERE color_id = %d AND color_status = %d", $color_id, $status ) );			
						
		}
		
		return false;		
		
	} 
	
	
	
	
	
	 
	
	/**
	 * Update color code
	 *  
	 * @param array $color_data
	 *
	 * @return bool 	 
	 * @since 1.0
	*/
	public function update_color_code( $color_data = array() ) {
		
		global $wpdb;		 
		
		if( ! $_POST["color_id"] )
			return; 			
			
		$color_id 	=  trim( $_POST['color_id'] );		
		
		$color_name	=	ucwords( strtolower( trim( $_POST["color_name"] ) ) );				
		$color_code	=	trim( $_POST["color_code"] );		
		
		$check_color_code  = $wpdb->get_row( $wpdb->prepare( "SELECT color_id FROM color_code WHERE color_code = '%s' AND color_id != %d ", $color_code, $color_id  ) );
		
		if( ! $check_color_code ){
			
			$color_data = array(						
							"color_name"				=> $color_name,	 
							"color_code"   				=> $color_code,							
							"color_updated_at"			=> current_time(), 
							"ip"			 			=> get_ip()	,
							);	 
		
			return $wpdb->update( "color_code", $color_data, array( "color_id" => $color_id  ) );   			  	
			
		}
		
		return false;
		 
	}
	
	
	
	
	
	
	/*********** Manage Status  ************/ 
	
 	/**
	 * To Add New Unique Color Code
	 *  
	 * @param color_data                  
	 *
	 * @return bool 	 
	 * @since 1.0
	 */ 
	public function add_new_status( $status_data = '' ) {
		
		global $wpdb;
		
		if( ! $_POST["status_name"] )
			return;		
		
		$status_name	=	ucwords( strtolower( trim( $_POST["status_name"] ) ) );		
		$status_desc	=	trim( $_POST["status_desc"] );		
		
		$check_status  = $wpdb->get_row( $wpdb->prepare( "SELECT status_id FROM status_panel WHERE status_name = '%s'", $status_name ) );
		
		if( ! $check_status ){
			
			$status_data	=	array(				
										"status_name"   => $status_name,			
										"status_desc"   => $status_desc,							
										'created_at' 	=> current_time(),
										'ip'            => get_ip(),
									);		

			return $wpdb->insert( 'status_panel', $status_data );
		}
	
		return false;
	
	}
	
	
	
	
	/**
	 * Get All Status Code List
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function get_all_status_list( $status = 0  ) {
		
		global $wpdb;		
		
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM status_panel WHERE status_check = %d ORDER BY `status_name` ASC", $status ) );
	}	
	
	
	/**
	 * Get All Information about Perticular Selected Color code
	 *
	 * @return $color_data Array
	 * @since 1.0
	 */
	public function get_selected_status_data( $status_id , $status = 0 ) {
		
		global $wpdb;		
		
		if( ! $status_id )
			return false;

		return	 $wpdb->get_row( $wpdb->prepare( "SELECT * FROM status_panel WHERE status_id = %d AND status_check = %d", $status_id, $status ) );			
		
	} 
	
	
	
	
	/**
	 * Update Status code
	 *  
	 * @param array $color_data
	 *
	 * @return bool 	 
	 * @since 1.0
	*/
	public function update_status_code( $status_data = array() ) {
		
		global $wpdb;		 
		
		if( ! $_POST["status_id"] )
			return; 			
			
		$status_id 			=  	trim( $_POST['status_id'] );				
		$status_name		=	ucwords( strtolower( trim( $_POST["status_name"] ) ) );				
		$status_desc		=	trim( $_POST["status_desc"] );		
		
		$check_status_code  = 	$wpdb->get_row( $wpdb->prepare( "SELECT status_id FROM status_panel WHERE status_name = '%s' AND status_id != %d ", $status_name, $status_id  ) );
		
		if( ! $check_status_code ){
			
			$status_data = array(						
								"status_name"		=> $status_name,	 
								"status_desc"   	=> $status_desc,							
								"updated_at"		=> current_time(), 
								"ip"			 	=> get_ip()	,
								);	 
		
			return $wpdb->update( "status_panel", $status_data, array( "status_id" => $status_id  ) );   			  	
			
		}
		
		return false;
		 
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/***********admin user************/
	
	
	
 	/**
	 * Get All Admin Users List
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function get_all_admin_user_list( $admin_status = 0  ) {
		
		global $wpdb;		
		
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM admin WHERE admin_status = %d AND admin_role != 'Admin' ORDER BY `admin_name` ASC", $admin_status ) );
	}	
	
	
	
	/**
	 * To Add New admin user
	 *  
	 * @param admin_data                  
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	
	public function add_admin_user( $user_data = '' ) {
		
		global $wpdb;
		
		$check_admin_user  = $wpdb->get_row( $wpdb->prepare( "SELECT admin_id FROM admin WHERE admin_email = %s", $_POST['admin_email'] ) );
		
		if( ! $check_admin_user ){
			
			$admin_email = strtolower( trim ( $_POST['admin_email'] ) );
			$color_id	=	(  $_POST["color_id"] ) ?  $_POST["color_id"] : 0;

		
			$user_data	=	array(				
				'admin_name'   			=> uc_words( strtolower( trim( $_POST['admin_name'] ) ) ),			
				'admin_email'   		=> $admin_email,			
				'admin_phone'   		=> $_POST['admin_phone'],			
				'admin_password'		=> md5( trim( $_POST['admin_password'] . AUTH_SALT ) ),
				"admin_role"			=> $_POST["admin_role"],
				"color_id"				=> $color_id,			
				'admin_created_at' 		=> current_time(),
				'admin_agent'			=> user_agent(),		
				'ip'               		=> get_ip(),
			);		

			return $wpdb->insert( 'admin', $user_data );
		}
	
		return false;
	
	}
	
	
	/**
	 * Get All Information about Perticular Selected ADmin Users 
	 *
	 * @return $user_data Array
	 * @since 1.0
	 */
	public function get_selected_admin_user_data( $admin_id , $admin_status = 0 ) {
		
		global $wpdb;		
		
		if( ! $admin_id )
			return false;

		return	 $wpdb->get_row( $wpdb->prepare( "SELECT * FROM admin WHERE admin_id = %d AND admin_status = %d", $admin_id, $admin_status ) );			
		
	} 
	
	/**
	 * Delete Perticular Selected ADmin User 
	 *  
	 * @param user_id Handles To delete User to match user_id 
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function admin_user_delete( $admin_id = '' ) {		
		
		if( ! $admin_id && ! $_POST['admin_id'] )
			return false;
		
		global $wpdb;
		
		$admin_id  =  isset( $_POST['admin_id'] ) ? $_POST['admin_id'] : $admin_id ;

		$wpdb->update( 'admin', array( 'admin_status'	=> 1 ), array( 'admin_id' => $admin_id ) ); 								
		
		return true;
   	}
	
	
	/**
	 * Update admin User Profile 
	 *  
	 * @param array $user_data
	 *
	 * @return bool 	 
	 * @since 1.0
	*/
	public function update_admin_user( $user_data = array() ) {
		
		global $wpdb;		 
				
		if( $_POST ) {
			
			$admin_email = strtolower( trim ( $_POST['admin_email'] ) );
			
			$color_id	=	(  $_POST["color_id"] ) ?  $_POST["color_id"] : 0;
			
			$user_data 	= array(						
								"admin_name"				=> uc_words ( $_POST["admin_name"] ),				
								"admin_email"   			=> $admin_email,
								"admin_role"				=> $_POST["admin_role"],
								"color_id"					=> $color_id,								
								"admin_phone"   			=> $_POST["admin_phone"],							
								"admin_updated_at"			=> current_time(),
								"admin_agent"				=> user_agent(),						
								"ip"			 			=> get_ip()	,
							);			
			
			$company_data = array(						
								"cognome_ragione_sociale"	=> uc_words ( $_POST["admin_name"] ),				
								"email"   					=> $admin_email,
								"role_id"					=> $_POST["admin_role"],
								"telefono_1"   				=> $_POST["admin_phone"],							
								"updated_at"				=> current_time(), 
								"ip"			 			=> get_ip()	,
							);	
								
			if( ! empty( $_POST["admin_password"] ) ) {
				
				$user_data["admin_password"]	= md5( trim( $_POST["admin_password"] . AUTH_SALT ) ); 
				$company_data["password"]		= md5( trim( $_POST["admin_password"] . AUTH_SALT ) );	
			} 	
			
			$wpdb->update( "admin", $user_data, array( "admin_id" => $_POST["admin_id"] ) );   			  					
			
			$wpdb->update( "companies", $company_data, array( "id" => $_POST["company_id"] ) );   	 
			
			return true;
			
		}  		
			 	    		
		return false;
	}
	
	
	
	 /**
	 for check color code used or not in users
	 
	 * @since 1.0
	 */
	public function check_color_code_exist_for_users( $color_id, $admin_id ) {
		
		global $wpdb;		
		
		$check_color_status  = $wpdb->get_row( $wpdb->prepare( "SELECT admin_id FROM admin WHERE color_id = %d AND admin_id != %d", $color_id, $admin_id ) );
		
		if( $check_color_status ){
			return true;
		}
		
		return false;
			
	}	
	
	 
	
	/**
	 * To Add New admin user
	 *  
	 * @param admin_data                  
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	
	public function add_admin_role( $role_data = '' ) {
		
		global $wpdb;
		
		$role_type	=	ucwords( strtolower( trim( $_POST["role_type"] ) ) );
		
		$check_role_type  = $wpdb->get_row( $wpdb->prepare( "SELECT role_id FROM admin_role WHERE role_type = %s", $role_type ) );
		
		if( ! $check_role_type ){
			
			$page_access =  implode( ",", $_POST['page_access'] );
			
			$role_data	=	array(				
				'role_type'   			=> $role_type,							 	
				'role_page_access'   	=> $page_access,				
				'role_created_at' 		=> current_time(),				 
				'ip'               		=> get_ip(),
			);		

			return $wpdb->insert( 'admin_role', $role_data );
		}
	
		return false;
	
	}
	
	
	/**
	 * Get All Admin Users List
	 *  
	 * @param $order_by by default set DESC
	 *
	 * @return result Object
	 
	 * @since 1.0
	 */
	public function get_all_admin_role_list() {
		
		global $wpdb;		
		
		return $wpdb->get_results( "SELECT * FROM admin_role ORDER BY `role_type` DESC" );
	}			
	
	
	
	/**
	 * Get All Information about Perticular Selected Role
	 *
	 * @return $role_data Array
	 * @since 1.0
	 */
	public function get_selected_role_data( $role_id ) {
		
		global $wpdb;		
		
		if( ! $role_id )
			return false;

		return	 $wpdb->get_row( $wpdb->prepare( "SELECT * FROM admin_role WHERE role_id = %d ", $role_id ) );			
		
	} 
	
	
	/**
	 * Update admin User Profile 
	 *  
	 * @param array $user_data
	 *
	 * @return bool 	 
	 * @since 1.0
	*/
	public function update_role( $role_data = array() ) {
		
		global $wpdb;		 
				
		if( $_POST ) {
			
			$page_access =  implode(",",$_POST['page_access']);
			
			$role_type	=	ucwords( strtolower( trim( $_POST["role_type"] ) ) );
			
			$role_data = array(						
				'role_type'   				=> $role_type,							 	
				'role_page_access'   		=> $page_access,					
				'role_updated_at'			=> current_time(),				 		
				'ip'			 			=> get_ip()	,
			);			
			
			return $wpdb->update( 'admin_role', $role_data, array( 'role_id' => $_POST['role_id'] ) );   			  
		}  		
			 	    		
		return false;
	}
	
	
	
	
	/**
	 * Send perticulare users email
	 *  
	 * @param email form
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function send_user_email( $email_data = array() ) {		
		
		$email = trim ( strtolower ( $_POST['email'] ) );
		 
		
		if( ! $email )
			return false;
		
		global $wpdb, $admin;
		
		$mail_template		= 	file_get_contents( SITE_URL . '/assets/email_template.html' );
		$mail_template		=	str_replace( "{{{year}}}", date("Y"), $mail_template );		
		$mail_template		=	str_replace( "{{{etrp}}}", "", $mail_template );
		
		$to					= 	$email;
		$subject			= 	$_POST['subject'];				
		$mail_body			= 	$_POST['message'];		
		
		$mail_template		=	str_replace( "{{{title}}}", $subject, $mail_template );			
		$mail_template		=	str_replace( "{{{mail_body}}}", $mail_body, $mail_template );		 
		
		$email_send_from	= 	$_POST['from_email'];
		$email_send_to		= 	$admin->get_admin_meta( 1, "en_email_send_to" ) . " " . $to;
		$mail_template		=	str_replace( "{{{mail_send_by}}}", $email_send_from, $mail_template );
		$mail_template		=	str_replace( "{{{mail_send_to}}}", $email_send_to, $mail_template );
		 	
		
		$body 				= $mail_template;    
		
		// This is headers
		$sender_name	= "Promoimpresa";
		$sender_email	= $email_send_from;
		$return_email	= $email_send_from;
		
		$headers 	 = "From: ".$sender_name." <".$sender_email.">" . "\r\n";
		$headers 	.= "Reply-To: ".$return_email."" . "\r\n";
		$headers 	.= "Return-Path: ".$return_email."\r\n";
		$headers  	.= "MIME-Version: 1.0\r\n";
		$headers 	.= "Content-type: text/html; charset: utf8\r\n";
		$headers 	.= "X-Mailer: PHP/" . phpversion()."\r\n";
		$headers 	.= "X-Priority: 1 (Highest)\n";
		$headers 	.= "X-MSMail-Priority: High\n";
		$headers 	.= "Importance: High\n"; 
		$attachments	= array();
		
		$sent =  wp_mail( $to, $subject, $body, $headers, $attachments ); 
		if( $sent ) {
		  echo "sent";
		}  else  {
		  echo "failed";
		}
		
		return;
			 
   	}
	
	
	
	
	
	
	
	/*********** mail formate *****************/ 
	
	
	/**
	* Update user registration mail structure
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_user_reg_mail( $mail_body	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_user_reg_sub', $_POST['en_user_reg_sub'] ); 
		$this->update_admin_meta( 1, 'it_user_reg_sub', $_POST['it_user_reg_sub'] ); 
		
		$this->update_admin_meta( 1, 'en_user_reg_body', $_POST['en_user_reg_body'] ); 
		$this->update_admin_meta( 1, 'it_user_reg_body', $_POST['it_user_reg_body'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_user_reg_sub', $_POST[ $singlelang->language . '_user_reg_sub'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_user_reg_body', $_POST[ $singlelang->language . '_user_reg_body'] ); 
				
			}
		}  
		
		return true; 
	}
	
	
	/**
	* Update user social registration mail structure
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_user_social_reg_mail( $mail_body	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_user_social_reg_sub', $_POST['en_user_social_reg_sub'] ); 
		$this->update_admin_meta( 1, 'it_user_social_reg_sub', $_POST['it_user_social_reg_sub'] ); 
		
		$this->update_admin_meta( 1, 'en_user_social_reg_body', $_POST['en_user_social_reg_body'] ); 
		$this->update_admin_meta( 1, 'it_user_social_reg_body', $_POST['it_user_social_reg_body'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_user_social_reg_sub', $_POST[ $singlelang->language . '_user_social_reg_sub'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_user_social_reg_body', $_POST[ $singlelang->language . '_user_social_reg_body'] ); 
				
			}
		}  
		
		return true; 
	}
	
	
	/**
	* Update forgot pw mail structure
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_forgot_pw_mail( $mail_body	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_forgot_pw_sub', $_POST['en_forgot_pw_sub'] ); 
		$this->update_admin_meta( 1, 'it_forgot_pw_sub', $_POST['it_forgot_pw_sub'] ); 
		
		$this->update_admin_meta( 1, 'en_forgot_pw_body', $_POST['en_forgot_pw_body'] ); 
		$this->update_admin_meta( 1, 'it_forgot_pw_body', $_POST['it_forgot_pw_body'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_forgot_pw_sub', $_POST[ $singlelang->language . '_forgot_pw_sub'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_forgot_pw_body', $_POST[ $singlelang->language . '_forgot_pw_body'] ); 
				
			}
		}  
		
		return true; 
	}
	
	
	/**
	* Update reset pw mail structure
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_reset_pw_mail( $mail_body	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_reset_pw_sub', $_POST['en_reset_pw_sub'] ); 
		$this->update_admin_meta( 1, 'it_reset_pw_sub', $_POST['it_reset_pw_sub'] ); 
		
		$this->update_admin_meta( 1, 'en_reset_pw_body', $_POST['en_reset_pw_body'] ); 
		$this->update_admin_meta( 1, 'it_reset_pw_body', $_POST['it_reset_pw_body'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_reset_pw_sub', $_POST[ $singlelang->language . '_reset_pw_sub'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_reset_pw_body', $_POST[ $singlelang->language . '_reset_pw_body'] ); 
				
			}
		}  
		
		return true; 
	}
	
	
	
	/**
	* Update reset pw mail structure
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_tipster_statistic_setting( $msg_data	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_tipster_statistic_footer_desc', $_POST['en_tipster_statistic_footer_desc'] ); 
		$this->update_admin_meta( 1, 'it_tipster_statistic_footer_desc', $_POST['it_tipster_statistic_footer_desc'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_tipster_statistic_footer_desc', $_POST[ $singlelang->language . '_tipster_statistic_footer_desc'] ); 
				
			}
		}  
		
		return true; 
	}
	
	
	
	/**Tipster section**/
	
	
	/**
	* Update tipster registration mail structure
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_tipster_reg_mail( $mail_body	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_tipster_reg_sub', $_POST['en_tipster_reg_sub'] ); 
		$this->update_admin_meta( 1, 'it_tipster_reg_sub', $_POST['it_tipster_reg_sub'] ); 
		
		$this->update_admin_meta( 1, 'en_tipster_reg_body', $_POST['en_tipster_reg_body'] ); 
		$this->update_admin_meta( 1, 'it_tipster_reg_body', $_POST['it_tipster_reg_body'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_tipster_reg_sub', $_POST[ $singlelang->language . '_tipster_reg_sub'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_tipster_reg_body', $_POST[ $singlelang->language . '_tipster_reg_body'] ); 
				
			}
		}  
		
		return true; 
	}
	
	
	/**
	* Update tispter forgot pw mail structure
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_tipster_forgot_pw_mail( $mail_body	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_tipster_forgot_pw_sub', $_POST['en_tipster_forgot_pw_sub'] ); 
		$this->update_admin_meta( 1, 'it_tipster_forgot_pw_sub', $_POST['it_tipster_forgot_pw_sub'] ); 
		
		$this->update_admin_meta( 1, 'en_tipster_forgot_pw_body', $_POST['en_tipster_forgot_pw_body'] ); 
		$this->update_admin_meta( 1, 'it_tipster_forgot_pw_body', $_POST['it_tipster_forgot_pw_body'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_tipster_forgot_pw_sub', $_POST[ $singlelang->language . '_tipster_forgot_pw_sub'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_tipster_forgot_pw_body', $_POST[ $singlelang->language . '_tipster_forgot_pw_body'] ); 
				
			}
		}  
		
		return true; 
	}
	
	
	 
	
	/**
	* Update tispter approval mail structure
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_tipster_approve_mail( $mail_body	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_tipster_approve_sub', $_POST['en_tipster_approve_sub'] ); 
		$this->update_admin_meta( 1, 'it_tipster_approve_sub', $_POST['it_tipster_approve_sub'] ); 
		
		$this->update_admin_meta( 1, 'en_tipster_approve_body', $_POST['en_tipster_approve_body'] ); 
		$this->update_admin_meta( 1, 'it_tipster_approve_body', $_POST['it_tipster_approve_body'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_tipster_approve_sub', $_POST[ $singlelang->language . '_tipster_approve_sub'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_tipster_approve_body', $_POST[ $singlelang->language . '_tipster_approve_body'] ); 
				
			}
		}  
		
		return true; 
	}
	
	
	/**
	* Update tispter reset pw mail structure
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_tipster_reset_pw_mail( $mail_body	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_tipster_reset_pw_sub', $_POST['en_tipster_reset_pw_sub'] ); 
		$this->update_admin_meta( 1, 'it_tipster_reset_pw_sub', $_POST['it_tipster_reset_pw_sub'] ); 
		
		$this->update_admin_meta( 1, 'en_tipster_reset_pw_body', $_POST['en_tipster_reset_pw_body'] ); 
		$this->update_admin_meta( 1, 'it_tipster_reset_pw_body', $_POST['it_tipster_reset_pw_body'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_tipster_reset_pw_sub', $_POST[ $singlelang->language . '_tipster_reset_pw_sub'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_tipster_reset_pw_body', $_POST[ $singlelang->language . '_tipster_reset_pw_body'] ); 
				
			}
		}  
		
		return true; 
	}
	 
	 
	/**
	* Update add tip mail data for tipsters
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_add_tip_mail( $mail_body	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_add_tip_sub', $_POST['en_add_tip_sub'] ); 
		$this->update_admin_meta( 1, 'it_add_tip_sub', $_POST['it_add_tip_sub'] ); 
		
		$this->update_admin_meta( 1, 'en_add_tip_body', $_POST['en_add_tip_body'] ); 
		$this->update_admin_meta( 1, 'it_add_tip_body', $_POST['it_add_tip_body'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_add_tip_sub', $_POST[ $singlelang->language . '_add_tip_sub'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_add_tip_body', $_POST[ $singlelang->language . '_add_tip_body'] ); 
				
			}
		}  
		
		return true; 
	}
	
	
	/**
	* Update add free tip mail 
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_add_free_tip_mail( $mail_body	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_add_free_tip_sub', $_POST['en_add_free_tip_sub'] ); 
		$this->update_admin_meta( 1, 'it_add_free_tip_sub', $_POST['it_add_free_tip_sub'] ); 
		
		$this->update_admin_meta( 1, 'en_add_free_tip_body', $_POST['en_add_free_tip_body'] ); 
		$this->update_admin_meta( 1, 'it_add_free_tip_body', $_POST['it_add_free_tip_body'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_add_free_tip_sub', $_POST[ $singlelang->language . '_add_tip_sub'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_add_free_tip_body', $_POST[ $singlelang->language . '_add_tip_body'] ); 
				
			}
		}  
		
		return true; 
	}
	
	
	/**
	* Update edit tip mail data for tipsters
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_edit_tip_mail( $mail_body	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_edit_tip_sub', $_POST['en_edit_tip_sub'] ); 
		$this->update_admin_meta( 1, 'it_edit_tip_sub', $_POST['it_edit_tip_sub'] ); 
		
		$this->update_admin_meta( 1, 'en_edit_tip_body', $_POST['en_edit_tip_body'] ); 
		$this->update_admin_meta( 1, 'it_edit_tip_body', $_POST['it_edit_tip_body'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_edit_tip_sub', $_POST[ $singlelang->language . '_edit_tip_sub'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_edit_tip_body', $_POST[ $singlelang->language . '_edit_tip_body'] ); 
				
			}
		}  
		
		return true; 
	}
	 
	
	/**
	* Update mail footer by admin
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_mail_footer_text( $mail_footer	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_email_send_from', $_POST['en_email_send_from'] ); 
		$this->update_admin_meta( 1, 'it_email_send_from', $_POST['it_email_send_from'] ); 
		
		$this->update_admin_meta( 1, 'en_email_send_to', $_POST['en_email_send_to'] ); 
		$this->update_admin_meta( 1, 'it_email_send_to', $_POST['it_email_send_to'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_email_send_from', $_POST[ $singlelang->language . '_email_send_from'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_email_send_to', $_POST[ $singlelang->language . '_email_send_to'] ); 
				
			}
		}  
		
		return true; 
	}
	
	
	
	/**
	* Update checkout mail structure
	*  
	* @return result Object
	
	* @since 1.0
	*/
	
	public function update_checkout_mail( $mail_body	=	array() ){		
		
		global $wpdb;		
		
		$this->update_admin_meta( 1, 'en_checkout_sub', $_POST['en_checkout_sub'] ); 
		$this->update_admin_meta( 1, 'it_checkout_sub', $_POST['it_checkout_sub'] ); 
		
		$this->update_admin_meta( 1, 'en_checkout_body', $_POST['en_checkout_body'] ); 
		$this->update_admin_meta( 1, 'it_checkout_body', $_POST['it_checkout_body'] ); 
		
		$all_langs	= $wpdb->get_results( "SELECT language FROM languages WHERE enable = 1 AND language NOT IN ( 'en', 'it_IT' )" );
		if( $all_langs ) {
			foreach( $all_langs as $singlelang ) {							
				
				$this->update_admin_meta( 1, $singlelang->language . '_checkout_sub', $_POST[ $singlelang->language . '_checkout_sub'] ); 
				
				$this->update_admin_meta( 1, $singlelang->language . '_checkout_body', $_POST[ $singlelang->language . '_checkout_body'] ); 
				
			}
		}  
		
		return true; 
	}
	
	
	
	/**
	* Update app background image
	*  
	* @param app_bg
	*
	* @return result Object
	
	* @since 1.0
	*/
	public function update_app_bg_setting( $app_bg = "" ){		
		
		global $wpdb;	 
		
		if( $_FILES['app_bg']['name'] ) {
						
			if( $_FILES['app_bg']['name'] ) {
		
				$sourcefile		= $_FILES['app_bg']['tmp_name'];
				
				$file_name 		= $_FILES['app_bg']['name'];
				$extension 		= strtolower( end( explode( ".", $file_name ) ) );
				$new_file_name	=	"promoimpresa_".mt_rand(10,100).".".$extension;
				
				$endfile		= SITE_DIR . '/uploads/app/'.$new_file_name;
				$type			= $_FILES['app_bg']['type'];
				
				$app_bg_upload	= makeThumbnail( $sourcefile, $max_width = 1200, $max_height = 1200, $endfile, $type );
			}	
	
			if( isset( $app_bg_upload ) ) { 
				
				$old_pic = $this->get_admin_meta( 1, "app_bg" );						
				unlink( SITE_DIR . "/uploads/app/".$old_pic);		
				
				$this->update_admin_meta( 1, "app_bg", $new_file_name );
							
				unset( $app_bg_upload );
				
			} 			
		} 
		
		return true; 
	}
	
	
	
	
	
	
	/************* Meta admin ********************/
	
	
	/**
	 * add/Update admin_meta table 
	 *  
	 * @param meta_key, meta_value, nation_id for Update 
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	public function update_admin_meta( $admin_id, $meta_key = "", $meta_value = "" ) {
	 	
		global $wpdb;
		
		if( ! $meta_key  || ! $admin_id )
			return false;
		
		$meta_id  = $wpdb->get_var( $wpdb->prepare( "SELECT meta_id FROM admin_meta WHERE admin_id = %d AND meta_key = %s", $admin_id, $meta_key ) );
		
		if( $meta_id ){	// Update			
			
			$wpdb->update( 'admin_meta', array( 'meta_value' => $meta_value ), array( 'meta_id' => $meta_id ) ); 
			
			return true;
			
		} else {	// Insert
			
			$admin_meta_data = array(						
				'admin_id' 		=> $admin_id,			
				'meta_key' 		=> $meta_key, 				
				'meta_value'	=> $meta_value,
			);		
						
			$wpdb->insert( 'admin_meta', $admin_meta_data );	 
			return true;					
		} 
	}
	
	/**
	 * Get Perticular meta data admin_meta table 
	 *  
	 * @param tab_data
	 *
	 * @return bool 	 
	 * @since 1.0
	 */
	
	public function get_admin_meta( $admin_id, $meta_key = "" ) {
		
		global $wpdb;	
		
		if( $meta_key && ! empty( $meta_key ) ) {	// get one field
			
			return $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM admin_meta WHERE admin_id = %d AND meta_key = %s", $admin_id, $meta_key ) );		
			
		} else {	// get all fields
			
			return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM admin_meta WHERE admin_id = %d", $admin_id ), ARRAY_N );	
			
		}
		
	}
	
	
	
} 