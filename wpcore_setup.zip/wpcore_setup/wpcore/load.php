<?php

require_once __DIR__ . DIRECTORY_SEPARATOR . "class-wp-error.php";
require_once __DIR__ . DIRECTORY_SEPARATOR . "class-smtp.php";
require_once __DIR__ . DIRECTORY_SEPARATOR . "class-phpmailer.php";
require_once __DIR__ . DIRECTORY_SEPARATOR . "wp-db.php";
require_once __DIR__ . DIRECTORY_SEPARATOR . "functions.php";
require_once __DIR__ . DIRECTORY_SEPARATOR . "wp_action_filter.php";