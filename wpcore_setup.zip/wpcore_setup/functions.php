<?php
// Write all functions here including add_action and all stuff
// var functions
if( ! function_exists('print_rr') ) {
	function print_rr( $content ) {
		echo "<pre>";
		print_r( $content );
		echo "</pre>";	
	}
} 

if ( ! function_exists( 'siget' ) ) {
	function siget( $name, $array = null ) {
		if ( ! isset( $array ) ) {
			$array = $_GET;
		}

		if ( isset( $array[ $name ] ) ) {
			return $array[ $name ];
		}

		return '';
	}
}

if ( ! function_exists( 'sipost' ) ) {
	function sipost( $name, $do_stripslashes = true ) {
		if ( isset( $_POST[ $name ] ) ) {
			return $do_stripslashes && function_exists( 'stripslashes_deep' ) ? stripslashes_deep( $_POST[ $name ] ) : $_POST[ $name ];
		}

		return '';
	}
}

if ( ! function_exists( 'siar' ) ) {
	function siar( $array, $name ) {
		if ( isset( $array[ $name ] ) ) {
			return $array[ $name ];
		}

		return '';
	}
}

if ( ! function_exists( 'siars' ) ) {
	function siars( $array, $name ) {
		$names = explode( '/', $name );
		$val   = $array;
		foreach ( $names as $current_name ) {
			$val = siar( $val, $current_name );
		}

		return $val;
	}
}

if ( ! function_exists( 'siempty' ) ) {
	function siempty( $name, $array = null ) {

		if ( is_array( $name ) ) {
			return empty( $name );
		}

		if ( ! $array ) {
			$array = $_POST;
		}

		$val = siar( $array, $name );

		return empty( $val );
	}
}

if ( ! function_exists( 'siblank' ) ) {
	function siblank( $text ) {
		return empty( $text ) && strval( $text ) != '0';
	}
}

if ( ! function_exists( 'siobj' ) ) {
	function siobj( $obj, $name ) {
		if ( isset( $obj->$name ) ) {
			return $obj->$name;
		}

		return '';
	}
}
if ( ! function_exists( 'siexplode' ) ) {
	function siexplode( $sep, $string, $count ) {
		$ary = explode( $sep, $string );
		while ( count( $ary ) < $count ) {
			$ary[] = '';
		}

		return $ary;
	}
}

if ( ! function_exists( 'number_formats' ) ) {
	function number_formats( $value = "" ) {		
		if ( $value == "" ) {
			$value = 0;
		} 	
		return number_format( $value, 2, '.', ',');		
	}
}

if ( ! function_exists( 'generateRandomString' ) ) {
	function generateRandomString($length = 10) {
    	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    	$charactersLength = strlen($characters);
    	$randomString = '';
	    for ($i = 0; $i < $length; $i++) {
    	    $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
    	return $randomString;
	}
}

if ( ! function_exists( 'formatSizeUnits' ) ) {
	 function formatSizeUnits($bytes)
		{
			if ($bytes >= 1073741824)
			{
				$bytes = number_format($bytes / 1073741824, 2) . 'GB';
			}
			elseif ($bytes >= 1048576)
			{
				$bytes = number_format($bytes / 1048576, 2) . 'MB';
			}
			elseif ($bytes >= 1024)
			{
				$bytes = number_format($bytes / 1024, 0) . 'KB';
			}
			elseif ($bytes > 1)
			{
				$bytes = $bytes . ' bytes';
			}
			elseif ($bytes == 1)
			{
				$bytes = $bytes . ' byte';
			}
			else
			{
				$bytes = '0 bytes';
			}
	
			return $bytes;
	}
}


function base64url_encode( $data ) { 
	return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' ); 
}

function base64url_decode( $data ) { 
	return base64_decode( str_pad( strtr( $data, '-_', '+/' ), strlen( $data ) % 4, '=', STR_PAD_RIGHT ) ); 
}

function date2mysql( $date = "", $is_only_date = false ) {		
	if ( $date == "" && $is_only_date ) {
		return "0000-00-00";
	} else if ( $date == "" && ! $is_only_date ) {
		return "0000-00-00 00:00:00";	
	}
	 
		
	$date	= str_replace( "/", "-", $date );
	$date	= str_replace( ".", "-", $date );	
	
	if ( $is_only_date ) {
		return date( "Y-m-d", strtotime( $date ) );
	} else {
		return date( "Y-m-d H:i:s", strtotime( $date ) );
	}
}




// Custome Code 

function view_full_date( $date = "", $is_only_date = false ) {		
	
	if ( $date == "" && $is_only_date ) {
		return "";
	} else if ( $date == "" && ! $is_only_date || $date == "0000-00-00 00:00:00" && ! $is_only_date ) {
		return "";	
	} 
		
	$date	= str_replace( "/", "-", $date );
	$date	= str_replace( ".", "-", $date );	
	
	if ( $is_only_date ) {
		return date( "Y-m-d", strtotime( $date ) );
	} else {
		return date( "d-m-Y H:i:s", strtotime( $date ) );
	}
}


function view_date( $date = "" ) {		
	if ( $date == "" ) {
		return "";
	} 
	if ( $date == "0000-00-00" ||  $date == "0000-00-00 00:00:00" ) {
		return "";
	} 		
	$date	= str_replace( "/", "-", $date );
	$date	= str_replace( ".", "-", $date );
	
	return date( "d/m/Y", strtotime( $date ) );	
}





// Get Current Date - Time  
function current_time( $timestamp = false ) {
	if( $timestamp )
		return time();
	else

		return date( "Y-m-d H:i:s" );				
}

// Get Current Date - Time  italia 
function view_current_time() {
	
	return date( "d-m-Y : H:i:s" );				
}

function custom_echo($x, $length)
{
  if(strlen($x)<=$length)
  {
    echo $x;
  }
  else
  {
    $y=substr($x,0,$length) . ' ...';
    echo $y;
  }
}



// Get Current Date
function current_date() {
	return date( "Y-m-d" );				
}

//  Get Current IP Address
function get_ip() {
	//return $_SERVER['REMOTE_ADDR']; 
	if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
    {
      $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $ip=$_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

// Get Current User  Agent Properties
function user_agent(){
	return $_SERVER['HTTP_USER_AGENT']; 
}



// Get Current Loged User All Information using Object 
if( ! function_exists( 'get_userinfo' ) ) {
	function get_userinfo( $user_id = "" ) {
		global $wpdb;
		
		if( ! $user_id )
			$user_id = $_SESSION['user_id']; 
		
		if( ! $user_id )
			return array();
			
		$userinfo	= $wpdb->get_row( $wpdb->prepare( "SELECT * FROM users WHERE user_id = %d", $user_id ) );
		
		return $userinfo;	 		
	}
}

// Make Word First Charecter Capital

function uc_words( $word = "" ) {
	global $wpdb;
	
	if( ! $word )
		return false;
	
	return ucwords( strtolower ( $word ) ) ;
}

// for trim string

function TrimData( $array )	{
	
  return trim($array);
}


function makeThumbnail($sourcefile,$max_width, $max_height, $endfile, $type){
// Takes the sourcefile (path/to/image.jpg) and makes a thumbnail from it
// and places it at endfile (path/to/thumb.jpg).

// Load image and get image size.
   	
	$image_info = getimagesize( $endfile );
	
	if ( $image_info['mime'] == 'image/jpeg' ) {
		$source_image = imagecreatefromjpeg( $endfile );
		imagejpeg( $endfile, $compress_image, 75 );
	} else if ( $image_info['mime'] == 'image/gif' ) {
		$source_image = imagecreatefromgif($endfile);
		imagegif($endfile, $compress_image, 75);
	} else if ( $image_info['mime'] == 'image/png' ) {
		$source_image = imagecreatefrompng($endfile);
		imagepng($endfile, $compress_image, 6);
	}
     
	switch($type){
		case'image/png':
		$img = imagecreatefrompng($sourcefile);
		break;
		case'image/jpeg':
		$img = imagecreatefromjpeg($sourcefile);
		break;
		case'image/gif':
		$img = imagecreatefromgif($sourcefile);
		break;
		default : 
		return 'Un supported format';
	}

	$width = imagesx( $img );
	$height = imagesy( $img );
	
	if ($width > $height) {
		if($width < $max_width)
			$newwidth = $width;
		
		else
		
		$newwidth = $max_width;	
		
		
		$divisor = $width / $newwidth;
		$newheight = floor( $height / $divisor);
	}
	else {
		
		 if($height < $max_height)
			 $newheight = $height;
		 else
			 $newheight =  $max_height;
		 
		$divisor = $height / $newheight;
		$newwidth = floor( $width / $divisor );
	}
	
	// Create a new temporary image.
	$tmpimg = imagecreatetruecolor( $newwidth, $newheight );

    imagealphablending($tmpimg, false);
    imagesavealpha($tmpimg, true);
	
	// Copy and resize old image into new image.
	imagecopyresampled( $tmpimg, $img, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
	
	// Save thumbnail into a file.
	
	//compressing the file
	
	
	switch($type){
		case'image/png':
			imagepng($tmpimg, $endfile, 0);
			break;
		case'image/jpeg':
			imagejpeg($tmpimg, $endfile, 100);
			break;
		case'image/gif':
			imagegif($tmpimg, $endfile, 0);
			break;	
	
	}
	
	// release the memory
   imagedestroy($tmpimg);
   imagedestroy($img);
   
   return true;
}
 

/****** Get Person Age Using Date Of Birth ********/
function get_age( $dob ) {

	$today = date("Y-m-d");
	$diff = date_diff(date_create($dob), date_create($today));
	return $diff->format('%y');
  
}


// Random Password Generate

function random_pass( $length = "6" ) {
		
	$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-=+?";
    $password = substr(str_shuffle( $chars ),0, $length );
	$password = "pron_".$password;
    return $password;
}

// Random Key Generate

function random_key( $length = "6" ) {
		
	$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $key = substr(str_shuffle( $chars ),0, $length );
	$key = "pron_".$key;
    return $key;
}

// Random transaction id
function random_transaction_id( $length = "7" ) {
		
	$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    $id = substr(str_shuffle( $chars ),0, $length );
 
    return $id;
}

/********************** Custome Paggination funactions ******************************/

function perpage( $count, $record_per_page = '10', $current_page_href ) {
	
	$output = '';
	
	if( ! isset( $_POST["page_no"] ) ) { 
		$_POST["page_no"] = 1;
	}
	
	if( $record_per_page != 0 ){
		$pages  = ceil($count/$record_per_page);
	}
	if( $pages > 1 ) {
		
		if( ( $_POST["page_no"] - 3 ) > 0 ) {
			if( $_POST["page_no"] == 1 )
				$output = $output . '<span id=1 class="current-page">1</span>';
			else				
				$output = $output . '<input type="submit" name="page_no" class="perpage-link" value="1" />';
		}
		if( ( $_POST["page_no"] - 3 ) > 1 ) {
				$output = $output . '...';
		}
		
		for( $i = ( $_POST["page_no"] - 2 ); $i <= ( $_POST["page_no"] + 2 ); $i++ )	{
			if( $i < 1 ) continue;
			if( $i > $pages ) break;
			if( $_POST["page_no"] == $i )
				$output = $output . '<span id='.$i.' class="current-page" >'.$i.'</span>';
			else				
				$output = $output . '<input type="submit" name="page_no" class="perpage-link" value="' . $i . '" />';
		}
		
		if( ( $pages - ( $_POST["page_no"] + 2 ) ) > 1 ) {
			$output = $output . '...';
		}
		if( ( $pages - ( $_POST["page_no"] + 2 ) ) > 0 ) {
			
			if( $_POST["page_no"] == $pages ){
				$output = $output . '<span id=' . ($pages) .' class="current-page">' . ($pages) .'</span>';
			} else {				
				$output = $output . '<input type="submit" class="perpage-link" name="page_no"   value="' . $pages . '" />';
			}
			
		}
		
	}
	return $output;
}

function showperpage( $sql, $record_per_page = 20, $current_page_href ) {	    
	
	global $wpdb;	
	
	$result  = $wpdb->get_results( $sql );		
	$count   = $wpdb->num_rows;	
	$perpage = perpage($count, $record_per_page, $current_page_href);
	
	return $perpage;
}

function android_curl_call( $fields = array() ) {
	
	if( ! $fields['registration_ids'] || ! is_array( $fields['registration_ids'] ) ) { 
		_log( "*** android_curl_call *** registration_ids empty ***" );
		return false;		
	}
	
	// Set POST variables
	$url	= 'https://fcm.googleapis.com/fcm/send';
	
	$headers	= array(
		'Authorization: key=' . FIREBASE_API_KEY,
		'Content-Type: application/json'
	);
	
	// Open connection
	$ch 	= curl_init();

	// Set the url, number of POST vars, POST data
	curl_setopt( $ch, CURLOPT_URL, $url );

	curl_setopt( $ch, CURLOPT_POST, true );
	curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers );
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );

	// Disabling SSL Certificate support temporarily
	curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );

	curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $fields ) );
	
	// Execute post
	$result = curl_exec( $ch );
		
	// Close connection
	curl_close( $ch );
	
	return $result === FALSE ? false : $result; 
}

function ios_curl_call( $device_token, $payload ) {
	
	$pem_file       = SITE_DIR . '/dist_certificates_prono.pem';
	$pem_secret     = '';
    $apns_topic     = 'HSquare.Pronostiok';
	
	$url = "https://api.development.push.apple.com/3/device/" . $device_token;
	//$url = "https://api.push.apple.com/3/device/$device_token";

    $ch = curl_init( $url );
    curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
    curl_setopt( $ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
    curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
											"apns-topic: " . $apns_topic
											));
    curl_setopt( $ch, CURLOPT_SSLCERT, $pem_file );
    curl_setopt( $ch, CURLOPT_SSLCERTPASSWD, $pem_secret );
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
    $response	= curl_exec( $ch );
    $httpcode 	= curl_getinfo( $ch, CURLINFO_HTTP_CODE );
	
	return $response ? $response : false;
}

/*
 *	function for send notification ios
*/
function ios_notification_send( $token_data = array(), $title = "", $msgbody = "", $type = "", $tip_id = "", $tipster_id = ""  ){
	
	if( $token_data && is_array( $token_data ) ) { 
		_log( "***** ios_notification_send *****" );	
		
		$body	= array();
			
		$body['aps'] = array(
							"notification_type"		=> $type,
							"title"					=> $title,
							"alert"					=> array(
														'title'	=> $title,
														'body'	=> $msgbody 
														),
							"body"					=> $msgbody,
							"is_from_notification"	=> "ios",
							"tipster_id"			=> $tipster_id,
							"tip_id"				=> $tip_id,
							"badge"					=> 1,
							"sound"					=> "default"
						);	
									
		_log( $body );					
							
		$payload = json_encode($body);
		
		foreach( $token_data as $token ){
			
			_log( 'device_token :' . $token );		
			
			$result	= ios_curl_call( $token, $payload );
			
			_log( 'result:' );
			_log( $result );		
		} 
						
		_log( "***** ios_notification_send END *****" );	
		
		return true;
	} else {
		_log( "*** ios_notification_send *** token_data empty ***" );
		return false;		
	}
	
	/*$passphrase = '';
	$ctx = stream_context_create();
	stream_context_set_option($ctx, 'ssl', 'local_cert', SITE_DIR . '/dist_certificates_prono.pem');
	stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
	
	// for production and distribution and adhoc test
	$fp = stream_socket_client('ssl://gateway.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx); 
	
	if ( ! $fp )
		return false;
		 
	$body	= array();
			
	$body['aps'] = array(
						"notification_type"		=> $type,
						"title"					=> $title,
						"alert"					=> $title,
						"body"					=> $msgbody,
						"is_from_notification"	=> "ios",
						"tipster_id"			=> $tipster_id,
						"tip_id"				=> $tip_id,
						"badge"					=> 1,
						"sound"					=> "default"
					);	
					
	_log( "***** ios_notification_send *****" );		
	_log( $body['aps'] );					
						
	// change device token here
	$payload = json_encode($body);
	
	foreach( $token_data as $token ){
		
		_log( 'token :' . $token );		
		
		$msg 	= chr(0) . pack('n', 32) . pack('H*', $token) . pack('n', strlen($payload)) . $payload;	
		$result = fwrite( $fp, $msg, strlen( $msg ) );	
		
		_log( 'Result:' );	
		_log( $result );		
	} 
			
	fclose( $fp );
	
	_log( "***** ios_notification_send END*****" );	
	
	return true;*/	
}

/* Store ajax and site url in script variable in all pages 
*  That helps to call ajax file while call operation using AJAX	
*/
function _define_js_variables( $page_name = "" ) {
	
	$defaults	= array(
		'ajax_url'  => AJAX_URL,
		'site_url'	=> SITE_URL
	);
						
	$defaults 	= apply_filters( 'defaults_js_variables', $defaults ); 
	
	if( ! $defaults || ! is_array( $defaults ) )
		return;
	

    echo '<script type="text/javascript">'. PHP_EOL;

	foreach( $defaults as $js_key => $js_var ){
		echo $js_key . ' = "' . $js_var . '";' . PHP_EOL;	
	}

	echo '</script>';							
}

add_action( 'after_haeder_scripts', '_define_js_variables', 10, 1 );



/************ Function for change language *******************/
function change_language() {
	 
	if( isset( $_POST['value'] ) && $_POST['value'] != "" ) {
	
		$site_lang = $_POST['value'];
				
		// For sesstion
		if( $site_lang == "en" ) {			
			$_SESSION['lang']	= 'en'; 		
		} elseif( $site_lang == "it" ) {		
			$_SESSION['lang']	= 'it';	   
		} else {
			$_SESSION['lang']	= $site_lang;	   	
		}
		
		// For Cookies		
		setcookie("lang", $site_lang, time() + ( 60 * 60 * 24 * 7 ), "/");
		
		global $menu_url;
			
		$url	= SITE_URL . "/" . ( $menu_url[ $_POST['pagename'] ][ $_SESSION['lang'] ] ? $menu_url[ $_POST['pagename'] ][ $_SESSION['lang'] ] : $menu_url[ $_POST['pagename'] ]['it'] );
		
	 	 
		if( $_POST['pagename'] == 'reset_password' ){
			$url	= $url . "/".$_POST["pass_arg"];
		}
		
		if( $_POST['pagename'] == 'user_profile' ){
			$url	= $url . "/".$_POST["pass_arg"];
		}
		
		if( $_POST['pagename'] == 'tipster_profile' ){
			$url	= $url . "/".$_POST["pass_arg"];
		} 
		
		if( $_POST['pagename'] == 'reset_tipster_password' ){
			$url	= $url . "/".$_POST["pass_arg"];
		}
		
		if( $_POST['pagename'] == 'add_tips' && $_POST["pass_arg"] ){
			$url	= $url . "/".$_POST["pass_arg"];
		}
		
		if( $_POST['pagename'] == 'edit_tips' ){
			$url	= $url . "/".$_POST["pass_arg"];
		}
		
		if( $_POST['pagename'] == 'tip_result' ){
			$url	= $url . "/".$_POST["pass_arg"];
		}
		
		if( $_POST['pagename'] == 'sub_guide' && $_POST["pass_arg"] ){
			$url	= $url . "/".$_POST["pass_arg"];
		}
		
		if( $_POST['pagename'] == 'selected_tipster_profile' ){
			$url	= $url . "/".$_POST["pass_arg"];
		}
		
		echo $url;				
	}
	
	die();
}
add_action( 'wp_ajax_change_language', 'change_language' );

/************ Function for change language *******************/
function check_cart_session() {
	 
	if( empty ( $_SESSION['packages'] )) {		
		echo "true";		
	} else {
		echo "No";		
	}	
	die();
}
add_action( 'wp_ajax_check_cart_session', 'check_cart_session' );


/************ Function for change language *******************/
function validateAge() {
	
	if( isset( $_REQUEST['value'] ) && $_REQUEST['value'] != "") {	
		
		$user_dob  = date2mysql ( $_REQUEST['value'], true );			 
		$age = 18;
		
		// $birthday can be UNIX_TIMESTAMP or just a string-date.
		if(is_string($user_dob)) {
			$user_dob = strtotime($user_dob);
		}
	
		// check
		// 31536000 is the number of seconds in a 365 days year.
		if(time() - $user_dob < $age * 31536000)  {
			echo "Not Valid";
		} else {
			echo "Valid";	
		}
	}
	 
}
add_action( 'wp_ajax_validateAge', 'validateAge' );


if( ! function_exists( '_log' ) ) {
	function _log( $msg = "" ) {
			
		$msg	= ( is_array( $msg ) || is_object( $msg ) ) ? print_r( $msg, 1 ) : $msg;
			
		error_log( date('[Y-m-d H:i:s e] ') . " [IP: " . $_SERVER['REMOTE_ADDR'] . "] " . $msg . PHP_EOL, 3, SITE_DIR . "/logs/log_" . date( 'd_m_Y' ) . ".log" );
	}
} 