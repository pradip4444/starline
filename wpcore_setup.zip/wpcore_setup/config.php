<?php
// Italia time zone
//date_default_timezone_set('Europe/Rome');

//error_reporting( E_ALL & ~E_NOTICE & ~E_STRICT & ~E_WARNING );

//ini_set("memory_limit","-1");

if( ! session_id() )
	@ session_start();
	
	
if( ! defined('SITE_URL') ) 	
	define('SITE_URL', 'http://192.168.0.107/crmpromoimpresa');	// Write URL without /	
	
	
if( ! defined('SITE_DIR') )
	define('SITE_DIR', __DIR__);		// This will return path without /
	
if( ! defined("SITE_TITLE") )
	define("SITE_TITLE", "Promoimpresa");	
	
if( ! defined("SITE_TITLE_SORT") )
	define("SITE_TITLE_SORT", "");	

if( ! defined('AJAX_URL') )
	define('AJAX_URL', SITE_URL . '/ajax.php');




if( ! defined('DB_HOST') )
	define('DB_HOST', "localhost");

if( ! defined('DB_USER') )
	define('DB_USER', "root");

if( ! defined('DB_PASSWORD') ) 
	define('DB_PASSWORD', "");

if( ! defined('DB_NAME') )
	define('DB_NAME', "crmpromoimpresa");
	
	
	
if( ! defined("AUTH_SALT") )
	define("AUTH_SALT", "RzX6*?HM#Lfb2JujZMyTWP.Kfp{FggQ+IVt~6:aMwO+ky=spPg,/g(wEf;Ek?*~/");	

		
// General configuration
if( ! defined("SUCCESS_STATUS") ) 
	define('SUCCESS_STATUS', 'true');

if( ! defined("ERROR_STATUS") ) 
	define('ERROR_STATUS', 'false');

if( ! defined("SUCCESS_RESCODE") ) 
	define('SUCCESS_RESCODE', '0000');

if( ! defined("DEBUG_MODE") ) 
	define('DEBUG_MODE', true);

if( ! defined("DEBUG_MODE_LONG") ) 
	define('DEBUG_MODE_LONG', true);
	  

//Stripe api SECTET key LIVE
if( ! defined("STRIPE_SECRET_KEY") )
	define('STRIPE_SECRET_KEY', 'sk_test_zr3LL54vJGPw4MnFXnTY9E0p');
	
//Stripe api PUBLISHABLE key
if( ! defined("STRIPE_PUBLISHABLE_KEY") )
	define('STRIPE_PUBLISHABLE_KEY', 'pk_test_W8oTkRzppjo1bRUrkJjZiQXL');			

/*******************/	

//Firebase Server API Key	
if( ! defined("FIREBASE_API_KEY") )
	define('FIREBASE_API_KEY', 'AAAAF-zH25U:APA91bFd9GUP6EyAebYU7nXGuBPq1qDNxcIiQ6O42swjY6CSAsXopzns14VOmNu940G5ct5jFfApsx-IQWu_FvGg_VAvuuawA0h-hFmGaZA16CXAS4EpMwmW5zg-SCoAq1FpE-JukpbJ');


/*if( ! defined( 'PAYPAL_CLIENT_ID' ) )
	define( 'PAYPAL_CLIENT_ID', 'ASBEUJNBQBU5QrcJY_AacIe-6_ROJIE-1LiNSXq0WLjkzmiKGmhZrOBiV0D18cZQCazms4Nbn04MTzw2' );	

if( ! defined( 'PAYPAL_CLIENT_SECRET' ) )
	define( 'PAYPAL_CLIENT_SECRET', 'EK2q2KDqlrB6quP0cgPEnHcu51qd4sp74sIyEwYqM_Mk5oOmoOhClMdylJ3FCAD-XO0fayxVYKZDpXst' );*/
	
if( ! defined( 'PAYPAL_CLIENT_ID' ) )
	define( 'PAYPAL_CLIENT_ID', 'AfEPP-mZ9fnyoVQK1XuKtY8BcnbxDjsFQG3O_pyij9-14bNRP6y7W6OsBg3YD3CMatRvgrUI8pHfBgfZ' );	

if( ! defined( 'PAYPAL_CLIENT_SECRET' ) )
	define( 'PAYPAL_CLIENT_SECRET', 'EK2mjfdGLwJYmMlvOK0LiOFDgT1EzREAwf7tzNXqcDk9weoqV6Wi6Jg0Ke4F9QKXfn3oc9vSUhK8OBR_' );
	
/*************** wpmail smtp settings  *********************/	


if( $sendinblue ){
	
	
	if( ! defined( 'USE_SMTP' ) )
		define( 'USE_SMTP', true );	
		
	if( ! defined( 'SMTP_HOST' ) )
		define( 'SMTP_HOST', 'smtp-relay.sendinblue.com' );			
		
	if( ! defined( 'SMTP_AUTH_TYPE' ) )
		define( 'SMTP_AUTH_TYPE', 'ssl' );			
		
	if( ! defined( 'SMTP_PORT' ) )
		define( 'SMTP_PORT', '587' );		
		
	if( ! defined( 'SMTP_USERNAME' ) )
		define( 'SMTP_USERNAME', 'info@gtechgroup.it' );
		
	if( ! defined( 'SMTP_PASSWORD' ) )
		define( 'SMTP_PASSWORD', '9G7Vd3gUT0pcXKON' );	
	
} else {
	
	if( ! defined( 'USE_SMTP' ) )
		define( 'USE_SMTP', true );	
	
	if( ! defined( 'SMTP_HOST' ) )
		define( 'SMTP_HOST', 'shcl-51f22.serverlet.com' );			
		
	if( ! defined( 'SMTP_AUTH_TYPE' ) )
		define( 'SMTP_AUTH_TYPE', false );			
		
	if( ! defined( 'SMTP_PORT' ) )
		define( 'SMTP_PORT', '587' );		
		
	if( ! defined( 'SMTP_USERNAME' ) )
		define( 'SMTP_USERNAME', 'smtp@shcl-51f22.serverlet.com' );
		
	if( ! defined( 'SMTP_PASSWORD' ) )
		define( 'SMTP_PASSWORD', 'Y.5.tF4YvQ1o4uYd' );			
	
}
 
	


// total paggination record per page for admin side
if( ! defined('RECORD_PER_PAGE') )
	define('RECORD_PER_PAGE', "20"); 
 
  		
if( ! class_exists('wpdb') )
	require_once SITE_DIR . '/wpcore/load.php';	

require_once SITE_DIR . '/functions.php';



$site_lang	= 'en';

if( $_SESSION['lang'] && $_SESSION['lang'] != "" ) {
	$site_lang	= $_SESSION['lang']; 			
} elseif( $_COOKIE['lang'] && $_COOKIE['lang'] != "" )  {	
	$site_lang			= $_COOKIE['lang']; 	
	$_SESSION['lang']	= $site_lang; 
} else {
	// IP
	//$geoinfo	= maybe_unserialize( file_get_contents( 'http://www.geoplugin.net/php.gp?ip=' . get_ip() ) );
	//$site_lang	= $geoinfo['geoplugin_countryCode'] == 'IT' || $geoinfo['geoplugin_countryCode'] == 'ITA' ? 'it' : 'en';
	$site_lang	= 'it';
	$_SESSION['lang']	= $site_lang;
	setcookie("lang", $site_lang, time() + ( 60 * 60 * 24 * 7 ), "/" );		
}

if( ! defined("LANG") )
	define( LANG, $site_lang );

if( ! defined("WP_DEBUG") )
	define( WP_DEBUG, true );


if( ! defined("WP_DEBUG_DISPLAY") )
	define( WP_DEBUG_DISPLAY, true );



// for admin side

$admin_lang	= 'en';

if( $_SESSION['language'] && $_SESSION['language'] != "" ) {	
	$language	= $_SESSION['language']; 				
	if( $language == "english" ){
		$admin_lang	= 'en';	
	} else {
		$admin_lang	= 'it';	
	}
} 


global $wpdb, $error_code;

$error_code 	= array();



//Username, password, db name, server name
$wpdb	= new wpdb(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);

$wpdb->query( 'SET character_set_results=utf8' );
//$wpdb->query( 'SET names=utf8' );
$wpdb->query( 'SET character_set_client=utf8' );
$wpdb->query( 'SET character_set_connection=utf8' );
$wpdb->query( 'SET character_set_results=utf8' );
$wpdb->query( 'SET collation_connection=utf8_general_ci' );



require_once SITE_DIR . "/load.php";	// Load all classes and functions

if( ! defined( "IS_DEBUG" ) )
	define( IS_DEBUG, ( isset( $_GET['_debug'] ) && $_GET['_debug'] ) ? 1 : 0 );
	
do_action( "init" );	
 