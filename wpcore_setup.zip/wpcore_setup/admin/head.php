<meta charset="UTF-8">
<meta name="viewport" content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Remove Tap Highlight on Windows Phone IE -->
<meta name="msapplication-tap-highlight" content="no"/>

<title>Promoimpresa</title>


<!-- uikit -->
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/admin/bower_components/uikit/css/uikit.almost-flat.min.css" media="all">
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/admin/assets/icons/flags/flags.min.css" media="all">
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/admin/assets/css/style_switcher.min.css" media="all">
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/admin/assets/css/main.min.css" media="all">
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/admin/assets/css/themes/themes_combined.min.css" media="all">
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/admin/assets/css/custome.css" media="all">


 <!-- weather icons -->
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/admin/bower_components/weather-icons/css/weather-icons.min.css" media="all">
<!-- metrics graphics (charts) -->
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/admin/bower_components/metrics-graphics/dist/metricsgraphics.css">
<!-- chartist -->
<link rel="stylesheet" href="<?php echo SITE_URL; ?>/admin/bower_components/chartist/dist/chartist.min.css">

<link rel="stylesheet" href="<?php echo SITE_URL; ?>/admin/assets/skins/dropify/css/dropify.css">

<link href="<?php echo SITE_URL; ?>/admin/assets/css/select2.css" rel="stylesheet" />

<?php do_action( 'after_haeder_scripts', $page_name ); ?>

 
 