/*
*	Js for All Modual script functions modal wise
*	=============================================	
*/  
 
 
 //only numbers not allow float values
$(".numbers").keypress(function (e) {
   if (e.which != 8 && e.which != 0  && (e.which < 48 || e.which > 57)) 
	  return false;
});


// with floating number

// floating value extra 
$('.number').keypress(function(event) {
    var $this = $(this);
    if ((event.which != 46 || $this.val().indexOf('.') != -1) &&
       ((event.which < 48 || event.which > 57) &&
       (event.which != 0 && event.which != 8))) {
           event.preventDefault();
    }

    var text = $(this).val();
    if ((event.which == 46) && (text.indexOf('.') == -1)) {
        setTimeout(function() {
            if ($this.val().substring($this.val().indexOf('.')).length > 3) {
                $this.val($this.val().substring(0, $this.val().indexOf('.') + 3));
            }
        }, 1);
    }

    if ((text.indexOf('.') != -1) &&
        (text.substring(text.indexOf('.')).length > 2) &&
        (event.which != 0 && event.which != 8) &&
        ($(this)[0].selectionStart >= text.length - 2)) {
            event.preventDefault();
    }      
});


$(".datepicker_only").keypress(function (event) {	
   if (event.which != 8 && event.which != 0 ) 
	  return false;
});




/*
$(function() {
  $('[data-toggle="datepicker"]').datepicker({	
	format: 'dd/mm/yyyy'
  });
});

 
$(function() {
      $('[data-toggle="datepicker"]').datepicker({
        autoHide: true,
        zIndex: 2048,
      });
    });
 
*/
/* Check Verified Password Or Note */
function validatePassword(){
	var password = document.getElementById("password")
  , confirm_password = document.getElementById("confirm_password");	
	if (password.value == '') {
		return true;
	}
	else{
		if(password.value != confirm_password.value) {
			confirm_password.setCustomValidity("New password and Confirm password should be matched.");
		} else {
			confirm_password.setCustomValidity('');
		}
	}
		
}

// Restrick to Enter '@' Char.

 
$('.restrict-special-characters').keyup(function()
{
	var yourInput = $(this).val();
	//re = /[@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi;
	re = /[@]/gi;
	var isSplChar = re.test(yourInput);
	if(isSplChar)
	{
		//var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
		var no_spl_char = yourInput.replace(/[@]/gi, '');
		    $.alert({
				title: 'Alert!',
				content: "'@' symbol not allow.",
			});
		$(this).val(no_spl_char);
	}	
	
});
  
 
/*************** company registry *******************/

/* Function For free tip Delete by admin */

function confirm_company_registry_delete( id ){					

	 
	UIkit.modal.confirm(
		'Non sarai in grado di recuperarlo Azienda!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_company_registry', id: id }, function ( result ) {  
		 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Azienda e stato cancellato.!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/clienti/company_registry_list.php' );	
			}, 1000);
		});
	});		
}

 
 
 
/*************** country *******************/

/* Function For country Delete by admin */

function confirm_country_delete( id ){					

	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel paese!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_country', country_id: id }, function ( result ) {  
		 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il paese e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/country/country_list.php' );	
			}, 1000);
		});
	});		
} 

/*************** operatori *******************/

/* Function For operatori Delete by admin */

function confirm_operatori_delete( id ){					

	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel operatori!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_operatori', operatori_id: id }, function ( result ) {  
		 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il operatori e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/settings/operatori_list.php' );	
			}, 1000);
		});
	});		
}


/*************** Materie Decenti *******************/
 

function confirm_materie_decenti_delete( id ){					

	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel Materia Docenti!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_materia_docenti', docenti_id: id }, function ( result ) {  
		 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il Materia Docenti e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/tabelle_operative/materia_docenti.php' );	
			}, 1000);
		});
	});		
}
 

function confirm_tipologia_contratto_delete( id ){					

	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel Tipologia Contratto!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_tipologia_contratto', contratto_id: id }, function ( result ) {  
		 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il Tipologia Contratto e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/tabelle_operative/tipologia_contratto.php' );	
			}, 1000);
		});
	});		
}


function confirm_contratto_fascia_delete( id ){					

	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel Contratti per Fascia!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_contratto_fascia', con_fascia_id: id }, function ( result ) {  
		 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il Contratti per Fascia e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/tabelle_operative/contratti_importi_per_fascia.php' );	
			}, 1000);
		});
	});		
}


function confirm_gruppo_servizi_delete( id ){					

	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel Gruppo Servizi!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_gruppo_servizi', gruppo_servizi_id: id }, function ( result ) {  
		 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il Gruppo Servizi e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/tabelle_operative/gruppo_servizi.php' );	
			}, 1000);
		});
	});		
}


function confirm_dettaglio_servizi_delete( id ){		 
	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel Dettaglio Servizi!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_dettaglio_servizi', dettaglio_servizi_id: id }, function ( result ) {  
		 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il Dettaglio Servizi e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/tabelle_operative/dettaglio_servizi.php' );	
			}, 1000);
		});
	});		
}
 

function confirm_settore_candidatura_delete( id ){		 
	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel Settore Candidatura!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_settore_candidatura', candidatura_id: id }, function ( result ) {  
		 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il Settore Candidatura e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/tabelle_operative/settore_candidatura.php' );	
			}, 1000);
		});
	});		
} 

function confirm_sotto_settore_candidatura_delete( id ){		 
	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel Sotto Settore Candidatura!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_sotto_settore_candidatura', sotto_candidatura_id: id }, function ( result ) {  
		 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il Sotto Settore Candidatura e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/tabelle_operative/sotto_settore_candidatura.php' );	
			}, 1000);
		});
	});		
}
 
function confirm_gruppo_titoli_studio_delete( id ){		 
	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel Gruppo Titoli di Studio!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_gruppo_titoli_studio', id: id }, function ( result ) {  
		 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il Gruppo Titoli di Studio e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/tabelle_operative/gruppo_titoli_studio.php' );	
			}, 1000);
		});
	});		
} 

function confirm_sotto_gruppo_titoli_studio_delete( id ){		 
	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel Sotto Gruppo Titoli di Studio!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_sotto_gruppo_titoli_studio', id: id }, function ( result ) {  
		 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il Sotto Gruppo Titoli di Studio e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/tabelle_operative/sotto_gruppo_titoli_studio.php' );	
			}, 1000);
		});
	});		
} 

// settings tabs
function confirm_fonte_contatto_candidato_delete( id ){		 
	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel Fonte Contatto Candidato!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_fonte_contatto_candidato', candidato_id: id }, function ( result ) {  
		 	 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il Fonte Contatto Candidato e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/settings/fonte_contatto_candidato.php' );	
			}, 1000);
		});
	});		
}

function confirm_city_delete( id ){		 
	 
	UIkit.modal.confirm(
		'Non sarai in grado di riportarlo indietro nel Citta!', 
		function(){ 
		$.post(ajax_url, { action: 'delete_city', city_id: id }, function ( result ) {  
		 	 
			modal = UIkit.modal.blockUI('<div class=\'uk-text-center\'>Il Citta e stato rimosso!<br/><img class=\'uk-margin-top\' src=\''+site_url + '/admin/assets/img/spinners/spinner.gif\' alt=\'\'>'); 
			setTimeout(function () {
				modal.hide();	
				window.location.href =  ( site_url + '/admin/settings/city_list.php' );	
			}, 1000);
		});
	});		
}



 
  