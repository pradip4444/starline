<?php
	include_once 'lang.php';
	
	global $menu_url;
	
	/* 	Admin Class For Admin Functionality To manage All Modual */		
	
	include_once 'classes/class-admin.php';
	
	
	/* 	Class For Manage All User Management Functionality
	*	register, login , Manage All User Modual
	*   get all user data, get selected user data , delete perticular user , edit perticular user
	*/		
	
	include_once 'classes/class-user.php';
	
	include_once 'classes/class-clienti.php';
	
	include_once 'classes/class-request.php';
	
	include_once 'classes/class-docenti.php';
	
	include_once 'classes/class-candidati.php';
	
	include_once 'classes/class-al.php';
	
	  
	
	/* 	Class For Manage All Bet Type Management Functionality
	*	get all bet type data, get selected bet type data , delete perticular bet type , edit perticular bet type
	*/	
	include_once 'classes/class-bet-type.php';
	
	
	/* 	Class For Manage All Tip Management Functionality
	*	get all tip data, get selected tip data , delete perticular tip , edit perticular tip
	*/	
	include_once 'classes/class-tip.php';
	 
	 
	
	/* 	Class For Manage Country Management Functionality
	*	get all Country data, get selected Country data , delete perticular Country , edit perticular Country
	*/	
	include_once 'classes/class-country.php';
	
	
	/* 	Class For Manage City Management Functionality
	*	get all City data, get selected City data , delete perticular City , edit perticular City
	*/	
	include_once 'classes/class-city.php';
	 
	 
	
	/* 	Class For Package Subscription  Provided By Tipster
	*	
	*/	
	include_once 'classes/class-package.php';
	
	
	/* 	Class For Create Page Data Iinserted by admin
	*	
	*/	
	include_once 'classes/class-guide.php';
	
	 
	/* 	Class For Manage News Latter  by admin
	*	
	*/	
	
	include_once 'classes/class-newsletter.php';
	
	
	/* 	Class For Manage language functionality by admin
	*	
	*/	
	
	include_once 'classes/class-language.php';
	
	
	/* 	Class For Manage Operatori Management Functionality
	*	get all Operatori data, get selected Operatori data , delete perticular Operatori , edit perticular Operatori
	*/	
	include_once 'classes/class-operatori.php';
	
	include_once 'classes/class-tabelle-operative.php';
	
	include_once 'classes/class-settings.php';
	
	
	global $user, $clienti, $request, $candidati, $al, $docenti, $admin, $bet_type, $tip, $country, $city, $package, $guide, $news_letter, $languages, $operatori, $tabelle_operative, $settings;
	
	if( ! is_a( $user, 'User' ) )
		$user 	= new User();
	
	if( ! is_a( $clienti, 'Client' ) )
		$clienti 	= new Client();
		
	if( ! is_a( $request, 'Request' ) )
		$request 	= new Request();	
	
	if( ! is_a( $docenti, 'Docenti' ) )
		$docenti 	= new Docenti(); 
		
	if( ! is_a( $candidati, 'Candidati' ) )
		$candidati 	= new Candidati(); 	
		
	if( ! is_a( $al, 'Al' ) )
		$al 	= new Al(); 		
		
	if( ! is_a( $admin, 'Admin' ) )
		$admin 	= new Admin();			 
		 
	if( ! is_a( $bet_type, 'Bet_Type' ) )
		$bet_type	= new Bet_Type();	
		
	if( ! is_a( $tip, 'Tip' ) )
		$tip 	= new Tip();							
		 
	if( ! is_a( $country, 'Country' ) )	
		$country = new Country(); 
		
	if( ! is_a( $city, 'City' ) )	
		$city = new City(); 	
		
		
	if( ! is_a( $package, 'Package' ) )
		$package = new Package();	
		
	if( ! is_a( $guide, 'Guide' ) )
		$guide = new Guide();										
	
	if( ! is_a( $coupons, 'News_Letter' ) )
		$news_letter = new News_Letter();	
		
	if( ! is_a( $languages, 'Languages' ) )
		$languages = new Languages();	
		
	if( ! is_a( $operatori, 'Operatori' ) )			
		$operatori = new Operatori();		 
		
	if( ! is_a( $tabelle_operative, 'Tabelle_Operative' ) )			
		$tabelle_operative = new Tabelle_Operative();		 	
		
	if( ! is_a( $settings, 'Settings' ) )			
		$settings = new Settings();		 	
	
		
		
		